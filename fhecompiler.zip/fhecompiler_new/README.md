# FHE Compiler for python frontend
This is the FHE Compiler for python frontend. It is built using the MLIR(Multi-Level Intermediate Representation) compiler framework.

## Install mlir
```sh
git clone https://github.com/llvm/llvm-project.git
mkdir llvm-project/build
cd llvm-project/build
cmake -G Ninja ../llvm\
   -DLLVM_ENABLE_PROJECTS=mlir\
   -DLLVM_BUILD_EXAMPLES=ON\
   -DLLVM_TARGETS_TO_BUILD=“Native;NVPTX;AMDGPU”\
   -DCMAKE_BUILD_TYPE=Release\
   -DLLVM_ENABLE_ASSERTIONS=ON
cmake --build . --target check-mlir
```
## Build fhecompiler
```sh
cd fhecompiler
cmake --build build --target install
```
## Install frontend
```sh
cd frontend
poetry install -E backend
```










