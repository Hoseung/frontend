![Tests](https://github.com/Desilo/compyler/actions/workflows/python-poetry.yml/badge.svg)
# CKKS transpiler!
## Developer board
[Here](https://www.notion.so/desilo/Compyler-4691ecd92ebe4473a84225d7291ac938#c41280e0eaec4b768d00dc071e08e1e2)
## Quickstart
```python
import compyler as cp

# Create a plan object choose the parameters for you
plan = cp.FheProgram() 

# Add an abstract variable with label "a" and scale 2**30
a = plan.add_secret("a", 30)

# Let's try to approximate 1/a using newton-rhapson division
b = -a + 2
c = a + 0
for i in range(5):
    c = c * (-c + 2)
    b = b * (-c + 2)
# After 5 iterations b should be more or less 
# b ≈ 1 / a

# compile the needed circuit
# this will put rescale and relinearize where needed
plan.compile(b)

# See the CKKS paramters calculated for you
print(plan.get_params())
# (32768, [60, 40, 40, 40, 40, 40, 40], [60])

# Create some test data for testing
plain_a = np.linspace(2 ** (-3), 1, plan.slots)

# execute the ckkks circuit using pyseal
ckks_result = plan.compute({"a": plain_a})

# execute the same circuit using numpy calculations
plain_result = plan.plain_compute({"a": plain_a})

# calculate the relative error
error = np.abs((ckks_result - plain_result) / plain_result)

print(np.mean(error))
# 0.00016613
```
## Installation
1. Clone this repo (`seal, pyseal` is not required, poetry takes care of that).
2. Run `poetry install -E backend` inside of the repo
3. Run `poetry run pytest` to check your installation
## Contribution
Help needed is always needed:
1. [ ] Add docs
2. [ ] Add and configure github pages for docs
3. [ ] Run `readme.md` and instantly find bugs
4. [ ] Report bugs
5. [ ] Request features
6. [ ] Let me what could've been done better. Suggest on the coding style improvements.