#!/usr/bin/env python3
import compyler as cp
import numpy as np

ABS_ERROR_THRESH = 1e-3


def test_basic():
    plan = cp.FheProgram()

    a = plan.add_secret("a", 30)
    b = -a + 2
    plan.compile(b)

    plain_a = np.linspace(2 ** (-3), 1, plan.slots)
    plain_result = plan.plain_compute({"a": plain_a})
    ckks_result = plan.compute({"a": plain_a})
    error = (ckks_result - plain_result) / plain_result
    assert all(error < ABS_ERROR_THRESH)


def test_squaring():
    plan = cp.FheProgram()

    a = plan.add_secret("a", 30)
    b = plan.add_secret("b", 30)

    c = (a + a) * (b * b)
    plan.compile(c)

    a_val = np.random.rand(plan.slots)
    b_val = np.random.rand(plan.slots)
    seal_compute = plan.compute({"a": a_val, "b": b_val})
    plain_compute = plan.compute({"a": a_val, "b": b_val})

    print(seal_compute - plain_compute)
    assert True


def test_power():
    plan = cp.FheProgram()

    a = plan.add_secret("a", 30)
    b = a**5
    plan.compile(b)

    a_plain = np.random.rand(plan.slots)
    err = plan.error_compute({"a": a_plain})

    # assert all(np.abs(err[0]) < ABS_ERROR_THRESH)
    assert all(np.abs(err[1]) < ABS_ERROR_THRESH)


def test_sum():
    plan = cp.FheProgram()

    a = plan.add_secret(
        "a",
        35,
    )
    c = a + a.sum()
    plan.compile(c)
    a_plain = np.random.rand(plan.slots)
    err = plan.error_compute({"a": a_plain})

    assert all(np.abs(err[0]) < ABS_ERROR_THRESH)
    assert all(np.abs(err[1]) < ABS_ERROR_THRESH)


def newton_rhapson_division():
    plan = cp.FheProgram()

    a = plan.add_secret("a", 30)

    # Newton rhapson inverse
    b = -a + 2
    c = a + 0
    for i in range(5):
        c = c * (-c + 2)
        b = b * (-c + 2)

    # b ≈ 1 / a

    plan.compile(b)

    plain_a = np.linspace(2 ** (-3), 1, plan.slots)
    plain_result = plan.plain_compute({"a": plain_a})
    ckks_result = plan.compute({"a": plain_a})
    error = (ckks_result - plain_result) / plain_result
    return error


def test_newton_rhapson_division_simple():
    error = newton_rhapson_division()
    assert all(np.abs(error) < ABS_ERROR_THRESH)


def test_newton_rhapson_division(benchmark):
    benchmark(newton_rhapson_division)


def maf_score():
    def inverse(x, d):  # 0 < x < 2
        a = -x + 2.0
        b = -x + 1.0

        for i in range(d):
            b = b * b
            a = a * (b + 1.0)

        return a

    def sqrt(x, d):  # 0 < x < 1
        a = x
        b = x - 1.0
        for i in range(d):
            a = a * (-b * 0.5 + 1.0)
            b = b * b * (b - 3.0) * 0.25
        return a

    def min_num(a, b, d):  # 0 < a,b < 1
        x = (a + b) * 0.5
        y = (a - b) * 0.5

        z = sqrt(y * y, d)

        return x - z

    def maf(a, b, d1=5, d2=5):
        return min_num(a, b, d1) * inverse(a + b, d2)

    plan = cp.FheProgram()

    a = plan.add_secret(
        "a",
        35,
    )
    b = plan.add_secret(
        "b",
        35,
    )

    d = maf(a, b, 5, 5)
    plan.compile(d)
    err = plan.error_compute(
        {"a": np.random.rand(plan.slots), "b": np.random.rand(plan.slots)}
    )

    return err[1]  # only abs error


def test_maf_score():
    error = maf_score()

    assert all(np.abs(error) < ABS_ERROR_THRESH)


def test_maf_score_bench(benchmark):
    benchmark(maf_score)


#     assert all(maf_score())
