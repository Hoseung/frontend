import compyler as cp


def test_cppcompile():
    plan = cp.FheProgram()

    a = plan.add_secret("a", 30)
    b = -a + 2
    c = b * b
    plan.cppcompile(c)



def test_cppcompile1():
    plan = cp.FheProgram()
    a = plan.add_secret("a", 30)

    # Newton rhapson inverse
    b = -a + 2
    c = a + 0
    b = c * b
    plan.cppcompile(b)



def test_cppcompile2():
    plan = cp.FheProgram()
    a = plan.add_secret("a", 30)

    # Newton rhapson inverse
    b = -a + 2
    c = a + 0
    for i in range(5):
        c = c * (-c + 2)
        b = b * (-c + 2)
    plan.cppcompile(b)

