#include <pybind11/pybind11.h>
#include <iostream>

namespace py = pybind11;
void processGraph(std::string path)
{
	// int value = py::cast<int>(node.attr("parents"));
	
	// std::cout << "the json path is: " << path;
}

PYBIND11_MODULE(cppgraph, m)
{
	m.def("process_graph", &processGraph, "Receive the graph from python to cpp");
}