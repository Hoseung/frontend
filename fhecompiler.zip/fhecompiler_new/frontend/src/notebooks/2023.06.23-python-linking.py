import compyler as cp
from compyler.utils import first
import networkx as nx
from networkx.readwrite import json_graph
import tempfile
import json


def node2dict(node: cp.node.Node):
    fields = dict(vars(node))
    fields.pop("children")
    fields.pop("parents")
    return fields


def node2nxgraph(root: cp.node.Node):
    nodenum = 1
    node2num = {root: nodenum}
    rootdict = node2dict(root)
    rootdict["type"] = str(type(root))
    rootdict["root"] = True

    G = nx.Graph()
    G.add_node(node2num[root], **rootdict)

    # adding nodes
    for par in root.traverse_parents(False):
        nodenum += 1
        node2num[par] = nodenum
        nodedict = node2dict(par)
        nodedict["root"] = False
        nodedict["type"] = str(type(par))
        G.add_node(node2num[par], **nodedict)

    # adding edges
    for par in root.traverse_parents(False):
        child = first(par.children)
        G.add_edge(node2num[child], node2num[par])

    return G


def write2file(G):
    data = json_graph.node_link_data(G)
    temp_filename = tempfile.mktemp()
    serialized_data = json.dumps(data, indent=2, default=lambda o: o.__dict__)
    with open(temp_filename, "w") as file:
        file.write(serialized_data)
    return temp_filename


plan = cp.CKKSplan()

a = plan.add("a", 35)
b = a**5

G = node2nxgraph(b)
write2file(G)
