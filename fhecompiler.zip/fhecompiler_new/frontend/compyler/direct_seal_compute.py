#!/usr/bin/env python3
from .cipher_node import CipherNode, PlainNode
from .operations import (
    Addition,
    Downscale,
    ModSwitch,
    Multiplication,
    Negation,
    Relinearize,
    Summation,
    UnaryOperation,
    Upscale,
)
from .plan import FheProgram
from .utils import first, get_cipher_node, get_plain_node, is_all_cipher, is_one_plain

SEAL_SCALE_EXACTNESS_TRES = 1e-1


def execute_plan_seal(ckksplan: FheProgram, value_dict):
    """
    Exectute the plan with directly in seal.

    By passes internal tuple IR.
    """
    import numpy as np
    import seal

    poly_modulus_degree = ckksplan.N
    parms = seal.EncryptionParameters(seal.scheme_type.ckks)
    parms.set_poly_modulus_degree(poly_modulus_degree)
    parms.set_coeff_modulus(
        seal.CoeffModulus.Create(
            poly_modulus_degree, ckksplan.modulus_chain + ckksplan.special_prime
        )
    )
    context = seal.SEALContext(parms)

    keygen = seal.KeyGenerator(context)
    public_key = keygen.create_public_key()
    secret_key = keygen.secret_key()
    relin_keys = keygen.create_relin_keys()

    encryptor = seal.Encryptor(context, public_key)
    evaluator = seal.Evaluator(context)
    encoder = seal.CKKSEncoder(context)
    decryptor = seal.Decryptor(context, secret_key)

    _ones = [1.0] * ckksplan.slots
    _zeros = [0.0] * ckksplan.slots

    topological_order = ckksplan.get_topological_order()
    seal_node_values = {}
    for node in topological_order:
        if len(node.parents) == 0:
            # Entering node
            if isinstance(node, CipherNode):
                temp = encoder.encode(
                    seal.VectorDouble(value_dict[node.label]), 2.0**node.params.scale
                )
                seal_node_values[node] = encryptor.encrypt(temp)

            elif isinstance(node, PlainNode):
                temp = encoder.encode(float(node.value), 2.0**node.params.scale)
                for _ in range(ckksplan.levels - node.params.level):
                    evaluator.mod_switch_to_next_inplace(temp)

                seal_node_values[node] = temp
            else:
                raise ValueError(f"Unsupported node type: {node}")
        elif isinstance(node, Addition):
            child_node = first(node.children)

            if len(node.parents) == 1:
                parent = first(node.parents)
                parent_cipher = seal_node_values[parent]
                temp = evaluator.add(parent_cipher, parent_cipher)

                seal_node_values[child_node] = temp

            elif len(node.parents) == 2:
                if is_all_cipher(node.parents):
                    parents = [seal_node_values[par] for par in node.parents]
                    # Hack (scales are approximately equal anyway)
                    if (
                        abs(np.log2(parents[0].scale()) - np.log2(parents[1].scale()))
                        > SEAL_SCALE_EXACTNESS_TRES
                    ):
                        [par.debug() for par in node.parents]
                        raise ValueError
                    parents[0].scale(parents[1].scale())
                    temp = evaluator.add(*parents)
                    seal_node_values[child_node] = temp

                elif is_one_plain(node.parents):
                    cipher = seal_node_values[get_cipher_node(node.parents)]
                    plain = seal_node_values[get_plain_node(node.parents)]

                    if (
                        abs(np.log2(cipher.scale()) - np.log2(cipher.scale()))
                        > SEAL_SCALE_EXACTNESS_TRES
                    ):
                        [par.debug() for par in node.parents]
                        raise ValueError

                    plain.scale(cipher.scale())

                    temp = evaluator.add_plain(cipher, plain)
                    seal_node_values[child_node] = temp
                else:
                    raise ValueError(f"Unsupported node type: {node}")

            else:
                raise ValueError(f"Unsupported node type: {node}")

        elif isinstance(node, Multiplication):
            child_node = first(node.children)

            if len(node.parents) == 1:
                parent = first(node.parents)
                parent_cipher = seal_node_values[parent]
                temp = evaluator.square(parent_cipher)
                seal_node_values[child_node] = temp

            elif len(node.parents) == 2:
                if is_all_cipher(node.parents):
                    parents = [seal_node_values[par] for par in node.parents]
                    # Hack (scales are approximately equal anyway)
                    temp = evaluator.multiply(*parents)
                    seal_node_values[child_node] = temp

                elif is_one_plain(node.parents):
                    cipher_node = get_cipher_node(node.parents)
                    cipher = seal_node_values[cipher_node]
                    plain = seal_node_values[get_plain_node(node.parents)]

                    tempzero = encoder.encode(_zeros, 2**cipher_node.params.scale)

                    temp = evaluator.add_plain(cipher, tempzero)
                    temp.scale(temp.scale() / plain.scale())

                    seal_node_values[child_node] = temp
                else:
                    raise ValueError(f"Unsupported node type: {node}")
            else:
                raise ValueError(f"Unsupported node type: {node}")
        elif isinstance(node, UnaryOperation):
            assert len(node.parents) == 1
            parent = first(node.parents)
            child = first(node.children)

            if isinstance(node, ModSwitch):
                this_lvl = parent.params.level
                target_lvl = node.target_node.params.level
                lvl_diff = this_lvl - target_lvl
                temp = evaluator.mod_switch_to_next(seal_node_values[parent])
                for _ in range(1, lvl_diff):
                    evaluator.mod_switch_to_next_inplace(temp)
                seal_node_values[child] = temp

            elif isinstance(node, Upscale):
                # lines = []
                # lines.append(f"plain_one = encoder.encode(_ones, {2**command[3]})")
                # lines.append(
                #     f"evaluator.mod_switch_to_inplace(plain_one, {command[2]}.parms_id())"
                # )
                # lines.append(f"{lab} = evaluator.multiply_plain({command[2]}, plain_one)")
                plain_one = encoder.encode(_ones, 2**node.scale)
                evaluator.mod_switch_to_inplace(
                    plain_one, seal_node_values[parent].parms_id()
                )
                temp = evaluator.multiply_plain(seal_node_values[parent], plain_one)
                seal_node_values[child] = temp

            elif isinstance(node, Downscale):
                # lines.append(f"plain_one = encoder.encode(_ones, {2**padded_scale})")
                # lines.append(
                #     f"evaluator.mod_switch_to_inplace(plain_one, {command[2]}.parms_id())"
                # )
                # lines.append(f"{lab} = evaluator.multiply_plain({command[2]}, plain_one)")
                # lines.append(f"evaluator.rescale_to_next_inplace({lab})")
                #
                from .plan import CKKS_PREFERRED_MODULUS

                rescaling_modulus = CKKS_PREFERRED_MODULUS

                padded_scale = rescaling_modulus - node.scale
                plain_one = encoder.encode(_ones, 2**padded_scale)
                evaluator.mod_switch_to_inplace(
                    plain_one, seal_node_values[parent].parms_id()
                )
                temp = evaluator.multiply_plain(seal_node_values[parent], plain_one)
                evaluator.rescale_to_next_inplace(temp)
                seal_node_values[child] = temp

            elif isinstance(node, Negation):
                temp = evaluator.negate(seal_node_values[parent])
                seal_node_values[child] = temp

            elif isinstance(node, Relinearize):
                temp = evaluator.relinearize(seal_node_values[parent], relin_keys)
                seal_node_values[child] = temp
            else:
                raise ValueError(f"Unsupported node type: {node}")
        else:
            continue
    result = decryptor.decrypt(seal_node_values[ckksplan.calc_result])

    return encoder.decode(result)


def execute_plan_tenseal(ckksplan: FheProgram, value_dict):
    """
    Exectute the plan with tenseal.seal

    By passes internal tuple IR.
    """
    import numpy as np
    import tenseal.sealapi as seal

    poly_modulus_degree = ckksplan.N
    parms = seal.EncryptionParameters(seal.SCHEME_TYPE(2))
    parms.set_poly_modulus_degree(poly_modulus_degree)
    parms.set_coeff_modulus(
        seal.CoeffModulus.Create(
            poly_modulus_degree, ckksplan.modulus_chain + ckksplan.special_prime
        )
    )
    context = seal.SEALContext(parms, True, seal.SEC_LEVEL_TYPE.TC128)

    keygen = seal.KeyGenerator(context)
    secret_key = keygen.secret_key()

    public_key = seal.PublicKey()
    keygen.create_public_key(public_key)

    relin_keys = seal.RelinKeys()
    keygen.create_relin_keys(relin_keys)

    if ckksplan.gal_keys_needed:
        gal_keys = seal.GaloisKeys()
        keygen.create_galois_keys(gal_keys)
    else:
        gal_keys = None

    encryptor = seal.Encryptor(context, public_key)
    evaluator = seal.Evaluator(context)
    encoder = seal.CKKSEncoder(context)
    decryptor = seal.Decryptor(context, secret_key)

    nslots = ckksplan.slots
    _ones = [1.0] * nslots
    _zeros = [0.0] * nslots

    topological_order = ckksplan.get_topological_order()
    seal_node_values = {}
    for node in topological_order:
        if len(node.parents) == 0:
            # Entering node
            if isinstance(node, CipherNode):
                temp = seal.Plaintext()
                encoder.encode(
                    list(value_dict[node.label]),
                    2.0**node.params.scale,
                    temp,
                )
                ciphertemp = seal.Ciphertext()
                encryptor.encrypt(temp, ciphertemp)
                seal_node_values[node] = ciphertemp

            elif isinstance(node, PlainNode):
                temp = seal.Plaintext()
                encoder.encode(float(node.value), 2.0**node.params.scale, temp)
                for _ in range(ckksplan.levels - node.params.level):
                    evaluator.mod_switch_to_next_inplace(temp)

                seal_node_values[node] = temp
            else:
                raise ValueError(f"Unsupported node type: {node}")

        elif isinstance(node, Addition):
            child_node = first(node.children)
            temp = seal.Ciphertext()

            if len(node.parents) == 1:
                parent = first(node.parents)
                parent_cipher = seal_node_values[parent]
                evaluator.add(parent_cipher, parent_cipher, temp)

                seal_node_values[child_node] = temp

            elif len(node.parents) == 2:
                if is_all_cipher(node.parents):
                    parents = [seal_node_values[par] for par in node.parents]
                    # Hack (scales are approximately equal anyway)
                    if (
                        abs(np.log2(parents[0].scale) - np.log2(parents[1].scale))
                        > SEAL_SCALE_EXACTNESS_TRES
                    ):
                        print("scale diff:")
                        print("cipher scale ", np.log2(parents[0].scale))
                        print("plain scale: ", np.log2(parents[1].scale))
                        print()
                        [par.debug() for par in node.parents]
                        raise ValueError
                    parents[0].scale = parents[1].scale
                    evaluator.add(parents[0], parents[1], temp)
                    seal_node_values[child_node] = temp

                elif is_one_plain(node.parents):
                    parent_cipher = seal_node_values[get_cipher_node(node.parents)]
                    plain = seal_node_values[get_plain_node(node.parents)]

                    if (
                        abs(np.log2(parent_cipher.scale) - np.log2(plain.scale))
                        > SEAL_SCALE_EXACTNESS_TRES
                    ):
                        print("scale diff:")
                        print("cipher scale ", np.log2(parent_cipher.scale))
                        print("plain scale: ", np.log2(plain.scale))
                        print()
                        [par.debug() for par in node.parents]
                        raise ValueError

                    plain.scale = parent_cipher.scale

                    evaluator.add_plain(parent_cipher, plain, temp)
                    seal_node_values[child_node] = temp
                else:
                    raise ValueError(f"Unsupported node type: {node}")

            else:
                raise ValueError(f"Unsupported node type: {node}")
            if temp.scale < 2**10:
                node.debug()
                raise ValueError(f"Too low scale: {node}")

        elif isinstance(node, Multiplication):
            child_node = first(node.children)
            temp = seal.Ciphertext()

            if len(node.parents) == 1:
                parent = first(node.parents)
                parent_cipher = seal_node_values[parent]
                evaluator.square(parent_cipher, temp)
                seal_node_values[child_node] = temp

            elif len(node.parents) == 2:
                if is_all_cipher(node.parents):
                    parents = [seal_node_values[par] for par in node.parents]
                    # Hack (scales are approximately equal anyway)
                    evaluator.multiply(parents[0], parents[1], temp)
                    seal_node_values[child_node] = temp

                elif is_one_plain(node.parents):
                    cipher_node = get_cipher_node(node.parents)
                    plain_node = get_plain_node(node.parents)
                    parent_cipher = seal_node_values[cipher_node]
                    plain = seal_node_values[plain_node]

                    tempzero = seal.Plaintext()
                    encoder.encode(_zeros, parent_cipher.scale, tempzero)
                    evaluator.mod_switch_to_inplace(tempzero, parent_cipher.parms_id())
                    evaluator.add_plain(parent_cipher, tempzero, temp)
                    temp.scale = 2.0 ** (
                        np.log2(temp.scale) - np.log2(plain_node.value)
                    )

                    seal_node_values[child_node] = temp
                else:
                    raise ValueError(f"Unsupported node type: {node}")
            else:
                raise ValueError(f"Unsupported node type: {node}")

            if temp.scale < 2**10:
                node.debug()
                raise ValueError(f"Too low scale: {node}")

        elif isinstance(node, UnaryOperation):
            assert len(node.parents) == 1
            parent = first(node.parents)
            child = first(node.children)
            temp = seal.Ciphertext()

            if isinstance(node, ModSwitch):
                this_lvl = parent.params.level
                target_lvl = node.target_node.params.level
                lvl_diff = this_lvl - target_lvl
                evaluator.mod_switch_to_next(seal_node_values[parent], temp)
                for _ in range(1, lvl_diff):
                    evaluator.mod_switch_to_next_inplace(temp)
                seal_node_values[child] = temp

            elif isinstance(node, Upscale):
                plain_one = seal.Plaintext()
                encoder.encode(_ones, 2**node.scale, plain_one)
                evaluator.mod_switch_to_inplace(
                    plain_one, seal_node_values[parent].parms_id()
                )
                evaluator.multiply_plain(seal_node_values[parent], plain_one, temp)
                seal_node_values[child] = temp

            elif isinstance(node, Downscale):
                from .plan import CKKS_PREFERRED_MODULUS

                rescaling_modulus = CKKS_PREFERRED_MODULUS

                padded_scale = rescaling_modulus - node.scale
                plain_one = seal.Plaintext()
                encoder.encode(_ones, 2**padded_scale, plain_one)
                evaluator.mod_switch_to_inplace(
                    plain_one, seal_node_values[parent].parms_id()
                )
                evaluator.multiply_plain(seal_node_values[parent], plain_one, temp)
                evaluator.rescale_to_next_inplace(temp)
                seal_node_values[child] = temp

            elif isinstance(node, Negation):
                evaluator.negate(seal_node_values[parent], temp)
                seal_node_values[child] = temp

            elif isinstance(node, Relinearize):
                evaluator.relinearize(seal_node_values[parent], relin_keys, temp)
                seal_node_values[child] = temp
            elif isinstance(node, Summation):
                assert gal_keys is not None
                parent_cipher = seal_node_values[parent]
                tempzero = seal.Plaintext()
                encoder.encode(_zeros, parent_cipher.scale, tempzero)
                evaluator.mod_switch_to_inplace(tempzero, parent_cipher.parms_id())

                sum_result = temp
                evaluator.add_plain(parent_cipher, tempzero, sum_result)

                rots_required = int(np.log2(encoder.slot_count()))
                for i in range(rots_required):
                    temp_sum = seal.Ciphertext()
                    evaluator.rotate_vector(sum_result, -(2**i), gal_keys, temp_sum)
                    evaluator.add_inplace(sum_result, temp_sum)

                seal_node_values[child] = temp
            else:
                raise ValueError(f"Unsupported node type: {node}")
        else:
            continue

    plain_res = seal.Plaintext()
    decryptor.decrypt(seal_node_values[ckksplan.calc_result], plain_res)

    return encoder.decode_double(plain_res)
