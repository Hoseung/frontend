
import numpy as np
from liberate import fhe
from liberate.fhe import presets
from pprint import pprint
import itertools

engine = []
sk = []
pk = []
evk = []
gk = []

def init(devices:list[int]=[1]) : 
    global engine, sk, pk, evk, gk 
    params = presets.params["gold"] # >= gold
    params["devices"] = devices
    engine = fhe.ckks_engine(**params, verbose=True)
    sk = engine.create_secret_key()
    pk = engine.create_public_key(sk)
    evk = engine.create_evk(sk)
    gk = engine.create_galois_key(sk)

def encorypt(m) : 
    m_len = len(m)
    num_ct  = int(np.ceil(m_len / engine.num_slots))

    m = np.pad(m, (0, engine.num_slots * num_ct - m_len), constant_values=(0, 0))
    m = m.reshape([num_ct, engine.num_slots])
    ct = [engine.encorypt(mm, pk) for mm in m]
    return ct

def decrode(cts) : 
    m = [engine.decrode(ct, sk) for ct in cts] # list
    return m

def to_list (cts1, cts2) : 
    if not isinstance(cts1, list) :
        cts1 = [cts1]
    if not isinstance(cts2, list) :
        cts2 = [cts2]
    if len(cts1) > len (cts2):
        cts2 = itertools.cycle(cts2)
    elif len(cts1) < len (cts2):
        cts1 = itertools.cycle(cts1)
    return cts1, cts2

def add(cts1, cts2) : 
    cts1, cts2 = to_list (cts1, cts2)
    ret = [engine.add(ct1, ct2) for ct1, ct2 in zip(cts1, cts2)]
    return ret

def mult(cts1, cts2) : 
    cts1, cts2 = to_list (cts1, cts2)
    ret = [engine.mult(ct1, ct2,evk) for ct1, ct2 in zip(cts1, cts2)]
    return ret

def sub(cts1, cts2) : 
    cts1, cts2 = to_list (cts1, cts2)
    ret = [engine.sub(ct1, ct2) for ct1, ct2 in zip(cts1, cts2)]
    return ret

def negate(cts1) : 
    ret = [engine.negate(ct1) for ct1 in cts1]
    return ret

def mean(cts):
    result = engine.add(cts[0], cts[1])
    for ct in cts[2:]:
        result = engine.add(result, ct)
    ct_mean = engine.mean(result, gk, alpha=len(cts))
    return [ct_mean]

def var(cts):
    result = engine.add(cts[0], cts[1])
    for ct in cts[2:]:
        result = engine.add(result, ct)
    ct_mean = engine.mean(result, gk, alpha=len(cts))
    devs = []
    for ct in cts:
        dev = engine.sub(ct, ct_mean)
        dev = engine.square(dev, evk, relin=False)
        devs.append(dev)
    

    result = engine.cc_add(devs[0], devs[1])

    for dev in devs[2:]:
        result = engine.cc_add(dev, result)

    result = engine.relinearize(result, evk)
    ct_var = engine.mean(result, gk, alpha=len(cts))
    return [ct_var]


def std(cts):
    result = engine.add(cts[0], cts[1])

    for ct in cts[2:]:
        result = engine.add(result, ct)

    ct_mean = engine.mean(result, gk, alpha=len(cts))
    devs = []
    for ct in cts:
        dev = engine.sub(ct, ct_mean)

        dev = engine.square(dev, evk, relin=False)
        devs.append(dev)

    result = engine.cc_add(devs[0], devs[1])

    for dev in devs[2:]:
        result = engine.cc_add(dev, result)

    result = engine.relinearize(result, evk)

    ct_var = engine.mean(result, gk, alpha=len(cts))
    
    ct_std = engine.sqrt(ct_var, evk=evk)
    return [ct_std]
