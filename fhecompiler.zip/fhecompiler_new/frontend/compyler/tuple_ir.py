from collections import deque

from .cipher_node import CipherNode, PlainNode
from .operations import (
    Addition,
    Downscale,
    ModSwitch,
    Multiplication,
    Negation,
    Relinearize,
    UnaryOperation,
    Upscale,
    Mean,
    Var,
    Std,
)
from .plan import FheProgram
from .utils import first, get_cipher_node, get_plain_node, is_all_cipher, is_one_plain


def graph2tuple(ckksplan: FheProgram):
    node2label = ckksplan.get_node2labels()
    topological_order = ckksplan.get_topological_order()

    t_ir = []

    for node in topological_order:
        if len(node.parents) == 0:
            # Entering node
            if isinstance(node, CipherNode):
                t_ir.append(("encrypt", node2label[node], node))
            elif isinstance(node, PlainNode):
                t_ir.append(
                    (
                        "encode",
                        node2label[node],
                        node,
                        ckksplan.levels - node.params.level,
                    )
                )
            else:
                raise ValueError(f"Unsupported node type: {node}")
        elif isinstance(node, Addition):
            child_label = node2label[first(node.children)]

            if len(node.parents) == 1:
                parent_label = node2label[first(node.parents)]
                t_ir.append(("add", child_label, parent_label, parent_label))

            elif len(node.parents) == 2:
                if is_all_cipher(node.parents):
                    parent_labels = [node2label[n] for n in node.parents]
                    t_ir.append(
                        ("add", child_label, parent_labels[0], parent_labels[1])
                    )
                elif is_one_plain(node.parents):
                    cipher_node = get_cipher_node(node.parents)
                    plain_node = get_plain_node(node.parents)
                    t_ir.append(
                        (
                            "add-plain",
                            child_label,
                            node2label[cipher_node],
                            node2label[plain_node],
                        )
                    )
                else:
                    raise ValueError(f"Unsupported node type: {node}")

            else:
                raise ValueError(f"Unsupported node type: {node}")

        elif isinstance(node, Multiplication):
            if len(node.parents) == 1:
                parent_label = node2label[first(node.parents)]
                child_label = node2label[first(node.children)]
                t_ir.append(("square", child_label, parent_label))
            elif len(node.parents) == 2:
                if is_all_cipher(node.parents):
                    parent_labels = [node2label[n] for n in node.parents]
                    child_label = node2label[first(node.children)]
                    t_ir.append(
                        ("multiply", child_label, parent_labels[0], parent_labels[1])
                    )
                elif is_one_plain(node.parents):
                    child_label = node2label[first(node.children)]
                    cipher_node = get_cipher_node(node.parents)
                    plain_node = get_plain_node(node.parents)
                    # For now only scale trick is supported
                    assert node.scale_trick
                    t_ir.append(
                        (
                            "scale_change",
                            child_label,
                            node2label[cipher_node],
                            plain_node.value,
                        )
                    )
                else:
                    raise ValueError(f"Unsupported node type: {node}")
            else:
                raise ValueError(f"Unsupported node type: {node}")
        elif isinstance(node, UnaryOperation):
            assert len(node.parents) == 1
            parent_label = node2label[first(node.parents)]
            child_label = node2label[first(node.children)]
            if isinstance(node, ModSwitch):
                this_lvl = first(node.parents).params.level
                target_lvl = node.target_node.params.level
                lvl_diff = this_lvl - target_lvl
                t_ir.append((node.label, child_label, parent_label, lvl_diff))

            elif isinstance(node, Upscale):
                t_ir.append(("upscale", child_label, parent_label, node.scale))

            elif isinstance(node, Downscale):
                t_ir.append(("downscale", child_label, parent_label, node.scale))

            elif isinstance(node, Negation) or isinstance(node, Relinearize) or isinstance(node, Mean) or isinstance(node, Var) or isinstance(node, Std):
                t_ir.append((node.label, child_label, parent_label))

            else:
                raise ValueError(f"Unsupported node type: {node}")
        else:
            continue

    return t_ir, node2label
    # return instruction_set
