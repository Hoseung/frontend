#!/usr/bin/env python3
import copy
from dataclasses import dataclass, replace

from .node import Node
from .operations import Operation, get_operation_node, STRING_LABEL_LIMIT


class FreeNode(Node):
    """
    Undetermined nodes.

    Node for "free" nodes: scale and level to be determined yet,
    Unfinished calculation nodes!
    """

    draw_shape = "oval"

    def __init__(self, value=None, label=None, children=None, parents=None):
        children = children if children is not None else set()
        parents = parents if parents is not None else set()
        super().__init__(children, parents)

        self.value = value
        self.label = label if label is not None else str(id(self))

    def _unary_op(self, op: Operation, rotation_amount=None):
        """Catcher for all unary ops."""
        parents = set([self])
        operation_node = get_operation_node(op, set(), parents)
        if rotation_amount is not None:
            operation_node.amount = rotation_amount

        self.children.add(operation_node)

        if len(self.label) > STRING_LABEL_LIMIT:
            new_label = f"{operation_node.label}(...)"
        else:
            new_label = f"{operation_node.label}({self.label})"

        res = FreeNode(value=None, parents=set([operation_node]), label=new_label)
        res.depth = self.depth + 1

        operation_node.children.add(res)

        return res

    def _binary_op(self, other, op: Operation):
        """Catcher for all binary ops."""
        # Turn plain python primitives into nodes
        if not isinstance(other, Node):
            other = PlainNode(other, str(other), CipherParams(None, None, None))

        parents = set([self, other])
        operation_node = get_operation_node(op, set(), parents)

        self.children.add(operation_node)
        other.children.add(operation_node)
        if len(other.label) + len(self.label) > STRING_LABEL_LIMIT:
            new_label = f"(... {operation_node.label} ...)"
        else:
            new_label = f"({self.label} {operation_node.label} {other.label})"
        res = FreeNode(value=None, parents=set([operation_node]), label=new_label)
        res.depth = self.depth + 1

        operation_node.children.add(res)

        return res

    def __rshift__(self, other: int):
        return self._unary_op(Operation.ROT, -other)

    def __lshift__(self, other: int):
        return self._unary_op(Operation.ROT, other)

    def __neg__(self):
        return self._unary_op(Operation.NEG)

    def __add__(self, other):
        return self._binary_op(other, Operation.ADD)

    def __sub__(self, other):
        return self + (-other)

    def __mul__(self, other):
        return self._binary_op(other, Operation.MUL)
    
    def mean (self) : 
        return self._unary_op(Operation.MEAN)
    
    def std (self) : 
        return self._unary_op(Operation.STD)
    
    def var (self) : 
        return self._unary_op(Operation.VAR)

    def __pow__(self, other: int):
        if other <= 0:
            raise ValueError("Only powers larger than zero supported.")
        if other == 1:
            return self
        if other % 2 == 0:
            half = self.__pow__(other / 2)
            return half * half
        else:
            half = self.__pow__(other // 2)
            return half * half * self

    def __repr__(self):
        return self.label
    

    def sum(self):
        """Rotation sum of the ciphertext."""
        return self._unary_op(Operation.SUM)


@dataclass
class CipherParams:
    scale: float
    min_scale: float
    level: int

    def copy(self, **kw):
        return replace(self, **kw)


class CipherNode(FreeNode):
    """
    Node for calulated cipher nodes: scale and level is set and not to be
    changed anymore
    """

    draw_shape = "record"

    def __init__(self, label: str, params: CipherParams):
        super().__init__(label=label)
        self.params = params

    def copy(self):
        """Copy node without children/parent connections.
        + copy cipher params
        """
        dup = copy.copy(self)
        dup.params = copy.copy(self.params)
        dup.parents = set()
        dup.children = set()
        dup.depth = self.depth + 1

        return dup

    def __repr__(self):
        out = "{"
        out += str(
            f"{self.label} | scale {self.params.scale} | min_scale {self.params.min_scale} | level {self.params.level} | depth {self.depth}"
        )
        out += "}"
        return out


class PlainNode(FreeNode):
    """
    Node for calculated plain nodes: scale and level is set and not to be
    changed anymore
    """

    draw_shape = "component"

    def __init__(self, value: float, label: str, params: CipherParams):
        super().__init__(value=value, label=label)
        self.params = params

    def __repr__(self):
        out = "{"
        out += str(
            f"{self.label} | scale {self.params.scale} | level {self.params.level}"
        )
        out += "}"
        return out
