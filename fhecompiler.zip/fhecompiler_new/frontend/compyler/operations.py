#!/usr/bin/env python3
from enum import Enum, auto

from math import log2

from .node import Node, substitute
from .utils import first, get_cipher_node, get_plain_node, is_all_cipher, is_one_plain

STRING_LABEL_LIMIT = 100

# This enum might be completely unnecessary..
class Operation(Enum):
    ADD = auto()
    MUL = auto()
    NEG = auto()
    ROT = auto()
    SUM = auto()
    MEAN= auto()
    STD = auto()
    VAR = auto()


def get_operation_node(operation: Operation, children, parents):
    """Return corresponding operation node."""
    if operation == Operation.ADD:
        return Addition(children, parents)
    if operation == Operation.MUL:
        return Multiplication(children, parents)
    if operation == Operation.NEG:
        return Negation(children, parents)
    if operation == Operation.ROT:
        return Rotation(children, parents)
    if operation == Operation.SUM:
        return Summation(children, parents)
    if operation == Operation.MEAN:
        return Mean(children, parents)
    if operation == Operation.STD:
        return Std(children, parents)
    if operation == Operation.VAR:
        return Var(children, parents)
    raise ValueError


class BinaryOperation(Node):
    draw_shape = "diamond"

    def __init__(self, children, parents):
        self.isexecuted = False
        self.result = None
        super().__init__(children, parents)

    def isvalid(self):
        pass


class Addition(BinaryOperation):
    def __init__(self, children, parents):
        super().__init__(children, parents)
        self.label = "+"

    def __repr__(self):
        return self.label

    def can_exec(self, parents=None) -> tuple[bool, Node]:
        if parents is None:
            parents = list(self.parents)
        # Already executed
        if self.isexecuted:
            print("The node is already executed, whatver")
            return True, self.result

        if is_all_cipher(parents):
            if len(parents) == 2:
                pars0 = parents[0]
                pars1 = parents[1]
            elif len(parents) == 1:
                pars0 = parents[0]
                pars1 = parents[0]
            else:
                raise ValueError

            cond1 = pars0.params.level == pars1.params.level
            cond2 = pars0.params.scale == pars1.params.scale

            if not (cond1 and cond2):
                return False, None

            new_lab = f"({pars0.label} {self.label} {pars1.label})"
            if len(new_lab) > STRING_LABEL_LIMIT:
                new_lab = f"(... {self.label} ...)"

            new_min_scale = max((p.params.min_scale for p in parents))

            new_params = pars0.params.copy(min_scale=new_min_scale)
            from .cipher_node import CipherNode

            result = CipherNode(new_lab, new_params)
            result.depth = max(pars0.depth, pars1.depth) + 1
            # child = first(self.children)
            # substitute(result, child)

            # self.isexecuted = True
            self.result = result
            return True, result

        elif is_one_plain(parents):
            cipher = get_cipher_node(parents)
            plain = get_plain_node(parents)

            plain.params = cipher.params.copy()

            new_lab = f"({cipher.label} {self.label} {plain.label})"
            if len(new_lab) > STRING_LABEL_LIMIT:
                new_lab = f"(... {self.label} ...)"

            new_params = cipher.params.copy()
            from .cipher_node import CipherNode

            result = CipherNode(new_lab, new_params)
            result.depth = cipher.depth + 1
            # child = first(self.children)
            # substitute(result, child)

            # self.isexecuted = True
            self.result = result
            return True, result

        return False, None


class Multiplication(BinaryOperation):
    def __init__(self, children, parents):
        super().__init__(children, parents)
        self.label = "×"
        self.scale_trick = True

    def __repr__(self):
        return self.label

    def can_exec(self, parents=None) -> tuple[bool, Node]:
        # Already executed
        if parents is None:
            parents = list(self.parents)
        if self.isexecuted:
            print("Already executed (maybe whatever)")
            return True, self.result
            # return False, None

        if is_all_cipher(parents):
            if len(parents) == 2:
                pars0 = parents[0]
                pars1 = parents[1]
            elif len(parents) == 1:
                pars0 = parents[0]
                pars1 = parents[0]
            else:
                raise ValueError

            cond1 = pars0.params.level == pars1.params.level
            if not cond1:
                return False

            new_lab = f"({pars0.label} {self.label} {pars1.label})"
            if len(new_lab) > STRING_LABEL_LIMIT:
                new_lab = f"(... {self.label} ...)"

            parent_min_scales = [p.params.min_scale for p in parents]
            new_min_scale = max(parent_min_scales)

            new_params = pars0.params.copy(
                min_scale=new_min_scale, scale=pars0.params.scale + pars1.params.scale
            )

            from .cipher_node import CipherNode

            result = CipherNode(new_lab, new_params)
            result.depth = max(pars0.depth, pars1.depth) + 1

            self.result = result
            return True, result

        elif is_one_plain(parents):
            cipher = get_cipher_node(parents)
            plain = get_plain_node(parents)
            plain.params = cipher.params.copy(scale=cipher.params.min_scale)

            new_lab = f"({cipher.label} {self.label} {plain.label})"
            if len(new_lab) > STRING_LABEL_LIMIT:
                new_lab = f"(... {self.label} ...)"
            new_params = cipher.params.copy(
                scale=cipher.params.scale - log2(plain.value)
            )

            from .cipher_node import CipherNode

            result = CipherNode(new_lab, new_params)
            result.depth = cipher.depth + 1

            self.result = result
            return True, result

        return False, None


class UnaryOperation(Node):
    draw_shape = "rpromoter"


class Negation(UnaryOperation):
    draw_shape = "invhouse"

    def __init__(self, children, parents):
        super().__init__(children, parents)
        self.label = "negate"

    def can_exec(self, parent) -> tuple[bool, Node]:
        result = parent.copy()
        result.label = " (-" + result.label + ")"
        return True, result

    def __repr__(self):
        return self.label


class Summation(UnaryOperation):
    draw_shape = "larrow"

    def __init__(self, children, parents):
        super().__init__(children, parents)
        self.label = "sum"

    def can_exec(self, parent) -> tuple[bool, Node]:
        result = parent.copy()
        result.label = " sum(" + result.label + ")"
        return True, result

    def __repr__(self):
        return self.label


class Rotation(UnaryOperation):
    draw_shape = "larrow"

    def __init__(self, children, parents):
        super().__init__(children, parents)
        self.label = "rotate"
        self.amount = 0

    def can_exec(self, parent) -> tuple[bool, Node]:
        result = parent.copy()
        result.label = " (" + result.label + f"≪ {self.amount})"
        return True, result

    def __repr__(self):
        return self.label


class Copy(UnaryOperation):
    draw_shape = "cds"

    def __init__(self, children, parents):
        super().__init__(children, parents)
        self.label = "copy"

    def __repr__(self):
        return self.label


class Relinearize(UnaryOperation):
    def __init__(self, children, parents):
        super().__init__(children, parents)
        self.label = "relin"

    def __repr__(self):
        return self.label


class Downscale(UnaryOperation):
    def __init__(self, children, parents, scale):
        super().__init__(children, parents)
        self.scale = scale
        self.label = f"downscale -{scale}"

    def __repr__(self):
        return self.label


class Upscale(UnaryOperation):
    def __init__(self, children, parents, scale):
        super().__init__(children, parents)
        self.scale = scale
        self.label = f"upscale +{scale}"

    def __repr__(self):
        return self.label


class Rescale(UnaryOperation):
    def __init__(self, children, parents):
        super().__init__(children, parents)
        self.label = "rescale"

    def __repr__(self):
        return self.label


class ModSwitch(UnaryOperation):
    def __init__(self, children, parents, target_node: Node):
        super().__init__(children, parents)
        self.target_node = target_node
        self.label = "modswitch-to"

    def __repr__(self):
        return self.label


class Mean(UnaryOperation):
    draw_shape = "invhouse"

    def __init__(self, children, parents):
        super().__init__(children, parents)
        self.label = "mean"

    def can_exec(self, parent) -> tuple[bool, Node]:
        result = parent.copy()
        result.label = " mean(" + result.label + ")"
        return True, result

    def __repr__(self):
        return self.label


class Var(UnaryOperation):
    draw_shape = "invhouse"

    def __init__(self, children, parents):
        super().__init__(children, parents)
        self.label = "var"

    def can_exec(self, parent) -> tuple[bool, Node]:
        result = parent.copy()
        result.label = " var(" + result.label + ")"
        return True, result

    def __repr__(self):
        return self.label
    

class Std(UnaryOperation):
    draw_shape = "invhouse"

    def __init__(self, children, parents):
        super().__init__(children, parents)
        self.label = "std"

    def can_exec(self, parent) -> tuple[bool, Node]:
        result = parent.copy()
        result.label = " std(" + result.label + ")"
        return True, result

    def __repr__(self):
        return self.label
    

