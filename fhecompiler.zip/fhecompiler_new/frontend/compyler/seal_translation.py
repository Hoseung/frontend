from jinja2 import Template

from .plan import FheProgram


def translate_command(command, plan):
    lab = command[1]
    match command[0]:
        case "encode":
            node = command[2]
            line1 = f"{lab} = encoder.encode(float({node.value}), {2.0**node.params.scale})\n"
            if command[3] > 0:
                lines = [f"{lab} = evaluator.mod_switch_to_next({lab})"]
                for i in range(1, command[3]):
                    lines.append(f"{lab} = evaluator.mod_switch_to_next({lab})")

                return line1 + "\n".join(lines)
            return line1
        case "encrypt":
            node = command[2]
            line1 = f"{node.label}_plain = encoder.encode(seal.VectorDouble({node.label}), 2**{node.params.scale})"
            line2 = f"{lab} = encryptor.encrypt({node.label}_plain)"
            return line1 + "\n" + line2

        case "multiply":
            return f"{lab} = evaluator.multiply({command[2]}, {command[3]})"
        case "scale_change":

            line1 = f"{command[2]}.scale({command[2]}.scale() / {command[3]})"

            line2 = f"{lab} = {command[2]}"
            return line1 + "\n" + line2
        case "add-plain":
            lines = [f"{command[3]}.scale({command[2]}.scale())"]
            lines.append(f"{lab} = evaluator.add_plain({command[2]}, {command[3]})")
            return "\n".join(lines)
        case "add":
            lines = [f"{command[2]}.scale({command[3]}.scale())"]
            lines.append(f"{lab} = evaluator.add({command[2]}, {command[3]})")
            return "\n".join(lines)

        case "negate":
            return f"{lab} = evaluator.negate({command[2]})"

        case "copy":
            return f"{lab} = {command[2]}"

        case "modswitch-to":
            lines = [f"{lab} = evaluator.mod_switch_to_next({command[2]})"]
            for i in range(1, command[3]):
                lines.append(f"{lab} = evaluator.mod_switch_to_next({lab})")
            return "\n".join(lines)

        case "relin":
            return f"{lab} = evaluator.relinearize({command[2]}, relin_keys)"

        case "rescale":
            return f"{lab} = evaluator.rescale_to_next({command[2]})"

        case "upscale":
            lines = []
            lines.append(f"plain_one = encoder.encode(_ones, {2**command[3]})")
            lines.append(
                f"evaluator.mod_switch_to_inplace(plain_one, {command[2]}.parms_id())"
            )
            lines.append(f"{lab} = evaluator.multiply_plain({command[2]}, plain_one)")

            return "\n".join(lines)

        case "downscale":
            lines = []
            # Hack...
            from .plan import CKKS_PREFERRED_MODULUS

            rescaling_modulus = CKKS_PREFERRED_MODULUS
            padded_scale = rescaling_modulus - command[3]
            lines.append(f"plain_one = encoder.encode(_ones, {2**padded_scale})")
            lines.append(
                f"evaluator.mod_switch_to_inplace(plain_one, {command[2]}.parms_id())"
            )
            lines.append(f"{lab} = evaluator.multiply_plain({command[2]}, plain_one)")
            lines.append(f"evaluator.rescale_to_next_inplace({lab})")

            return "\n".join(lines)

        case _ as error_case:
            raise ValueError(f"Unknown instruction: {error_case}")


def translate(plan: FheProgram):
    # environment = Environment(loader=FileSystemLoader("./templates/"))
    # template = environment.get_template("seal_template.py")
    import os

    __location__ = os.path.realpath(
        os.path.join(os.getcwd(), os.path.dirname(__file__))
    )

    with open(os.path.join(__location__, "templates/seal_template.py")) as file_:
        template = Template(file_.read())
        seal_preamble = template.render(
            poly_modulus_degree=plan.N, coeff=plan.modulus_chain
        )

        main_commands = []

        for command in plan.tuple_ir:
            main_commands.append(translate_command(command, plan))

        lines = seal_preamble + os.linesep + os.linesep + os.linesep.join(main_commands)

        return lines.split("\n")
