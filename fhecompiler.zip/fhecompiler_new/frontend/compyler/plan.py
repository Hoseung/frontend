from collections import deque
from copy import deepcopy
from enum import Enum, unique

from . import backend

import subprocess

import numpy as np

from .cipher_node import CipherNode, CipherParams, FreeNode, PlainNode
from .node import Node, insert_between, pad, pad_all, substitute, remove
from .operations import (
    Addition,
    BinaryOperation,
    Copy,
    Downscale,
    ModSwitch,
    Multiplication,
    Negation,
    Relinearize,
    Rescale,
    Summation,
    UnaryOperation,
    Upscale,
    Mean,
    Var,
    Std,
)
from .utils import first, is_all_cipher, is_one_plain

MAX_LEVEL = 1000
CKKS_LARGEST_MODULUS = 60
CKKS_PREFERRED_MODULUS = 40
CKKS_LOGQ_N = [(109, 4096), (218, 8192), (438, 16384), (881, 32768)]


@unique
class RescalePolicy(Enum):
    """Choose optimal rescaling policy regime."""

    MINIMAL_ERROR = 1
    MINIMAL_LATENCY = 2


class FheProgram:
    """Compiler for CKKS calculations."""

    def __init__(self, scheme="CKKS", size=None, path_ckks_opt:str="~/.local/bin/ckks-opt", devices:list[int]=[1]):
        """Init CKKS computation plan."""
        self.starting_nodes: Node = {}
        self.path_ckks_opt = path_ckks_opt # path for ckks-opt
        self.devices = devices # select gpus -> None: all, [0] : 0nd, [1] : 1st, [0, 1] : 0 and 1
        if size is None:
            self.N = None
        else:
            self.N = size * 2

        self.levels = MAX_LEVEL
        self.modulus_chain = [CKKS_LARGEST_MODULUS] + [
            CKKS_PREFERRED_MODULUS
        ] * self.levels
        self.special_prime = [CKKS_LARGEST_MODULUS]

        self.max_scale = 90
        self.rescale_policy = RescalePolicy.MINIMAL_ERROR
        self.gal_keys_needed = False
        self.calc_result = None

    @property
    def slots(self):
        """Return number vector slots."""
        return self.N // 2

    def get_params(self):
        """Return encryption parameters."""
        return self.N, self.modulus_chain, self.special_prime

    def add_secret(self, label, min_scale):
        """Add starting nodes, to the computation."""
        if label in self.starting_nodes:
            raise ValueError("Existing label received")
        new_params = CipherParams(min_scale, min_scale, self.levels)
        node = CipherNode(label, new_params)
        self.starting_nodes[label] = node

        return node

    def _dead_code_trim(self, root):
        all_nodes = set(root.traverse_neighbors())
        parents = set(root.traverse_parents())
        to_delete = []
        for node in all_nodes:
            if node not in parents:
                to_delete.append(node)
        print(f"Trimming {len(to_delete)} nodes.")
        for node in to_delete:
            remove(node)

    def _copy_pad_wave(self, root: Node):
        queue = deque()
        visited = set()
        for _, node in self.starting_nodes.items():
            queue.append(node)
            visited.add(node)
        while queue:
            node = queue.popleft()
            if isinstance(node, (BinaryOperation, UnaryOperation)):
                child = first(node.children)
                assert len(node.children) == 1
                assert child not in visited
                visited.add(child)
                queue.append(child)

            children = node.children
            binary_ops = [op for op in children if isinstance(op, BinaryOperation)]

            for bin_op in binary_ops:
                if len(binary_ops) > 1:
                    copy_node = Copy(set(), set())
                    insert_between(bin_op, node, copy_node)
                    parent_copy = node.copy()
                    insert_between(bin_op, copy_node, parent_copy)

                if bin_op not in visited:
                    queue.append(bin_op)
                    visited.add(bin_op)

    def _relin_wave(self, root: Node):
        parents = list(root.traverse_parents(False))
        for node in parents:
            condition_1 = isinstance(node, CipherNode)
            condition_2 = len(node.parents) == 1

            multiplication = first(node.parents)
            condition_3 = isinstance(multiplication, Multiplication)

            if multiplication is None:
                continue
            if is_one_plain(multiplication.parents):
                continue

            if not (condition_1 and condition_2 and condition_3):
                continue

            relin_node = Relinearize(set(), set())
            assert len(multiplication.children) == 1

            pad_all(node, relin_node)

    def _waterline_rescale_pad(self, child: Node, node: CipherNode) -> CipherNode:
        params = node.params
        rescaling_modulus = self.modulus_chain[params.level]
        if params.scale <= params.min_scale:
            return node

        rescale_amount = params.scale - params.min_scale

        assert rescaling_modulus > rescale_amount

        padded = pad(child, node, Downscale(set(), set(), rescale_amount))

        new_params = padded.params
        new_params.scale -= rescale_amount
        new_params.level -= 1

        return padded

    def _greedy_rescale_pad(self, child: Node, node: CipherNode) -> CipherNode:
        params = node.params
        rescaling_modulus = self.modulus_chain[params.level]
        if params.scale - rescaling_modulus < params.min_scale:
            return node

        padded = pad(child, node, Rescale(set(), set()))

        new_params = padded.params
        new_params.scale -= rescaling_modulus
        new_params.level -= 1

        return padded

    def _prepare_addition(
        self, child: Node, parents: list[Node]
    ) -> tuple[CipherNode, CipherNode]:
        if len(parents) == 2:
            a = parents[0]
            b = parents[1]
        elif len(parents) == 1:
            a = b = parents[0]
        else:
            raise ValueError("Unsupported parents number")

        if not is_all_cipher((a, b)):
            if isinstance(a, PlainNode):
                a, b = b, a
            assert isinstance(b, PlainNode)
            b.params = a.params.copy()
            return (a, b)
        # Ensure a.level > b.level
        if b.params.level > a.params.level:
            a, b = b, a

        level_diff = a.params.level - b.params.level
        if level_diff > 0:
            modswitch = ModSwitch(set(), set(), b)
            a = pad(child, a, modswitch)
            a.params.level = b.params.level

        if b.params.scale == a.params.scale:
            return (a, b)
        elif b.params.scale > a.params.scale:
            a, b = b, a

        assert a.params.scale > b.params.scale

        scale_diff = a.params.scale - b.params.scale

        upscale = Upscale(set(), set(), scale_diff)
        b = pad(child, b, upscale)

        b.params.scale += scale_diff

        return (a, b)

    def _prepare_multiplication(
        self, child: Node, parents: list[Node]
    ) -> tuple[CipherNode, CipherNode]:

        if len(parents) == 2:
            a = parents[0]
            b = parents[1]
        elif len(parents) == 1:
            a = parents[0]
            if self.rescale_policy == RescalePolicy.MINIMAL_LATENCY:
                a = self._greedy_rescale_pad(child, a)
            elif self.rescale_policy == RescalePolicy.MINIMAL_ERROR:
                a = self._waterline_rescale_pad(child, a)
            return (a, a)

        else:
            raise ValueError("Unsupported parents number")

        if not is_all_cipher((a, b)):
            if isinstance(a, PlainNode):
                a, b = b, a
            assert isinstance(b, PlainNode)
            b.params = a.params.copy()
            return (a, b)

        if self.rescale_policy == RescalePolicy.MINIMAL_LATENCY:
            a = self._greedy_rescale_pad(child, a)
            b = self._greedy_rescale_pad(child, b)
        elif self.rescale_policy == RescalePolicy.MINIMAL_ERROR:
            a = self._waterline_rescale_pad(child, a)
            b = self._waterline_rescale_pad(child, b)

        # Ensure a.level > b.level
        if b.params.level > a.params.level:
            a, b = b, a

        level_diff = a.params.level - b.params.level
        if level_diff > 0:
            modswitch = ModSwitch(set(), set(), b)
            a = pad(child, a, modswitch)
            a.params.level = b.params.level

        return (a, b)

    def _dfs_exec(self, node: Node):  # noqa: max-complexity: 13
        """
        Inplace (mutating) DFS traversal of the graph.

        This is the main method that rewrites the graph
        for the ckks computation.

        Important implementation notes:
        1. Bugs associated with graph rewriting probably originate here.
        2. Each recursive matching (if, elif statements below) should always
            retain a a valid graph a.k.a. graph invariant:
            `assert all(node in parent.children for parent in node.parents)`
            `assert all(node in child.parents for child in node.children)`
        3. Don't pollute this function with assert calls
        4. This is code causes silent bugs due to mutation of the traversed graph.
        5. Prefer using graph validity preserving functions from ./node.py
        6. Any ideas on how to improve this method are appreciated
        """
        if isinstance(node, CipherNode):
            return node

        elif isinstance(node, PlainNode):
            return node

        elif isinstance(node, FreeNode):

            return self._dfs_exec(first(node.parents))

        elif isinstance(node, UnaryOperation):
            parent = self._dfs_exec(first(node.parents))
            is_executable, result = node.can_exec(parent)

            if not is_executable:
                node.debug()
                raise RuntimeError

            node.parents = set([parent])
            node.children = set([result])

            result.parents = set([node])
            return result

        elif isinstance(node, BinaryOperation):
            # dfs should prefer "ancestors"
            parents_list = list(node.parents)
            parents_list.sort(key=lambda x: x.depth)

            parents = [self._dfs_exec(par) for par in parents_list]

            # Retain graph invariant
            node.parents = set(parents)
            for parent in parents:
                parent.children.add(node)

            if isinstance(node, Multiplication):
                new_parents = self._prepare_multiplication(node, parents)
            elif isinstance(node, Addition):
                new_parents = self._prepare_addition(node, parents)
            else:
                node.debug()
                raise ValueError("Unsupported operation")

            is_executable, result = node.can_exec(new_parents)

            if not is_executable:
                node.debug()
                raise RuntimeError

            # Retain graph invariant
            node.isexecuted = True
            node.parents = set(new_parents)

            old_result = first(node.children)
            substitute(result, old_result)

            return result
        else:
            node.debug()
            raise ValueError

    def _trim_levels(self, root: Node):
        min_level = root.params.level - 1

        root.params.level -= min_level
        for node in root.traverse_parents(False):
            if isinstance(node, CipherNode) or isinstance(node, PlainNode):
                node.params.level -= min_level
        return min_level

    def _rebuild(self, root: Node):
        """Backward pass to validate HE computation."""
        self._dead_code_trim(root)

        print("Executing what possible...")
        # self._eager_exec_wave(root)
        root = self._dfs_exec(root)
        print("Inserting relinearize nodes...")
        self._relin_wave(root)

        print("Padding with copies...")
        # self._copy_pad_wave(root)

        min_level = self._trim_levels(root)

        assert self.levels >= min_level
        self.levels -= min_level

        self.modulus_chain = [CKKS_LARGEST_MODULUS] + [
            CKKS_PREFERRED_MODULUS
        ] * self.levels

        this_log_Q = sum(self.modulus_chain) + self.special_prime[0]

        # Auto determination of N
        if self.N is None:
            for log_Q, N in CKKS_LOGQ_N:
                if log_Q >= this_log_Q:
                    self.N = N
                    break
            else:
                raise ValueError(
                    f"The circuit is too complex, logQ required: {this_log_Q}"
                )
        else:
            for log_Q, N in CKKS_LOGQ_N:
                if log_Q >= this_log_Q and self.N >= N:
                    break
            else:
                raise ValueError(
                    f"The circuit is too complex, loqQ required: {this_log_Q}"
                )

        self.root = root
        # if root not in first(root.parents).children:
        #     print("Success!")
        #     return first(first(root.parents).children)
        return root

    def _validate_graph(self):
        assert self.calc_result is not None
        e = self.calc_result
        nodes = set(i for i in e.traverse_parents())
        nodes.add(e)

        for node in nodes:
            for child in node.children:
                if child not in nodes:
                    node.debug()
                    raise ValueError("Graph inconsistency")

        for node in nodes:
            for parent in node.parents:
                if len(node.parents) != 0:
                    if node not in parent.children:
                        node.debug()
                        raise ValueError(
                            f"Graph inconsistency, node not in children {node}"
                        )
            for child in node.children:
                if node not in child.parents:
                    node.debug()
                    raise ValueError(f"Graph inconsistency, node not in parents {node}")

    def _update_gal_key_req(self):
        assert self.calc_result is not None
        e = self.calc_result
        nodes = set(i for i in e.traverse_parents())
        for node in nodes:
            if isinstance(node, Summation):
                self.gal_keys_needed = True
                break

    def draw(self, node=None):
        """
        Draw the calculation graph using graphviz.

        Requires graphviz bindings.
        """
        from .draw import draw_dot

        if node is None:
            node = self.calc_result
        draw_dot(node)

    def compile(self, node):
        """Build CKKS computation graph."""
        assert self.calc_result is None

        self.original_graph = deepcopy(node)
        output = self._rebuild(node)
        self.calc_result = output
        self._validate_graph()
        self._update_gal_key_req()

    def cppcompile(self, node):
        """Relegate compilation to cpp."""
        assert self.calc_result is None
        from cppgraph import process_graph
        from .json_serialization import write2file

        self.original_graph = deepcopy(node) ## temporary thing for plain_compute

        path = write2file(node)

        import os
        from pathlib import Path
        dest_dir = Path(os.environ['HOME']) / '.cache' / 'fhecompiler'
        # dest_dir.mkdir(parents=True, exist_ok=True)
        temp_filename = str( dest_dir / "test.json")
        str(temp_filename)

        import sys 
        path_local = '~/.local/bin'
        sys.path.append(os.path.expanduser(path_local))
        execute = f"{self.path_ckks_opt} {temp_filename}".encode("utf-8")
        popen = subprocess.Popen(
            [execute],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            shell=True
        )
        (stdoutdata, stderrdata) = popen.communicate()
        # print(stdoutdata)
        # print(stderrdata)
        if popen.returncode != 0 :
            print (f"Return code : {popen.returncode}")
            print (f"Make sure that ckks-opt is in your $PATH")
            print (f"Default install path is $HOME/.local/bin")
            print (f"{os.environ['HOME']}")
        
        process_graph(str(path))

        import sys
        import os
        sys.path.append(os.path.expanduser('~/.local/bin'))
        import imp
        import fhe_jit.out as out
        imp.reload(out)
        backend.init(devices=self.devices)


    def plain_compute(self, value_dict):
        """Perform calculation with unencrypted input for testing."""
        for label in value_dict:
            assert label in self.starting_nodes

        def helper(node):
            if isinstance(node, UnaryOperation):
                parent = first(node.parents)
                if isinstance(node, Negation):
                    return -helper(parent)
                if isinstance(node, Summation):
                    return sum(helper(parent))
                if isinstance(node, Mean):
                    return np.mean(helper(parent))
                if isinstance(node, Var):
                    return np.var(helper(parent))
                if isinstance(node, Std):
                    return np.std(helper(parent))
                raise NotImplementedError

            if isinstance(node, BinaryOperation):
                pars = list(node.parents)
                if len(pars) == 1:
                    a1 = helper(pars[0])
                    a2 = a1
                else:
                    a1 = helper(pars[0])
                    a2 = helper(pars[1])

                if isinstance(node, Addition):
                    return a1 + a2
                if isinstance(node, Multiplication):
                    return a1 * a2
                raise ValueError("Unexpected node type")

            if isinstance(node, CipherNode):
                return value_dict[node.label]

            if isinstance(node, PlainNode):
                return node.value

            if isinstance(node, FreeNode):
                assert len(node.parents) == 1
                parent = first(node.parents)
                return helper(parent)

            raise NotImplementedError

        return helper(self.original_graph)

    def get_topological_order(self):
        """
        Return topological order of the graph.

        Uses Kahn's topological sort
        https://www.geeksforgeeks.org/topological-sorting-indegree-based-solution/
        """
        calc_result = self.calc_result
        in_degrees = {}
        for node in calc_result.traverse_parents():
            in_degree = len(node.parents)
            in_degrees[node] = in_degree
        in_degrees[calc_result] = len(calc_result.parents)

        # populate the queue
        queue = deque()
        for node, in_degree in in_degrees.items():
            if in_degree == 0:
                queue.append(node)

        topological_order = []
        while queue:
            node = queue.popleft()
            topological_order.append(node)
            for child in node.children:
                in_degrees[child] -= 1
                if in_degrees[child] == 0:
                    queue.append(child)
        return topological_order

    def get_node2labels(self):
        """Assign arbitrary label to each node."""

        class LabelGenerator:
            def __init__(self):
                self.state = 0

            def get_label(self):
                output = "x" + str(self.state)
                self.state += 1
                return output

        lab_generator = LabelGenerator()
        calc_result = self.calc_result
        node2label = {}
        node2label[calc_result] = lab_generator.get_label()
        for node in calc_result.traverse_parents():
            node2label[node] = lab_generator.get_label()
        return node2label

    def _transpile2tupleir(self):
        from .tuple_ir import graph2tuple

        self.tuple_ir, self.node2label = graph2tuple(self)

        return self.tuple_ir, self.node2label

    def transpile2seal(self):
        """Output seal code for serialization."""
        self._transpile2tupleir()
        assert self.tuple_ir is not None

        from .seal_translation import translate

        seal_instructions = translate(self)
        return seal_instructions

    def transpile2defhe(self):
        """Output defhe code for serialization."""
        raise NotImplementedError("No defhe yet")

    def compute(self, value_dict, tenseal=True):
        """
        Perform calculation with seal ckks input for testing.

        Bypass tuple IR and unnecessary boilerplate.
        """
        import sys
        import os
        sys.path.append(os.path.expanduser('~/.local/bin'))
        import imp
        import fhe_jit.out as out
        imp.reload(out)
        # backend.init()
        for k, v in value_dict.items() :
            value_dict[k] = backend.encorypt(v)
        ret = out.test(**value_dict)

        return backend.decrode(ret)

        if not tenseal:
            from .direct_seal_compute import execute_plan_seal

            return execute_plan_seal(self, value_dict)

        from .direct_seal_compute import execute_plan_tenseal

        return np.array(execute_plan_tenseal(self, value_dict))

    def error_compute(self, value_dict, tenseal=True):
        """Calculate error between plain and seal calculation."""
        seal_calc = self.compute(value_dict, tenseal)
        plain_calc = self.plain_compute(value_dict)

        rel = seal_calc / plain_calc - 1
        abr = seal_calc - plain_calc
        print(f"Rel. error: {np.mean(rel):.3f} +- {np.std(rel):.3f}")
        print(f"Abs. error: {np.mean(abr):.3f} +- {np.std(abr):.3f}")
        return rel, abr
