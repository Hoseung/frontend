import seal

poly_modulus_degree = {{poly_modulus_degree}}
parms = seal.EncryptionParameters(seal.scheme_type.ckks)
parms.set_poly_modulus_degree(poly_modulus_degree)
parms.set_coeff_modulus(seal.CoeffModulus.Create(poly_modulus_degree, {{coeff}}))
context = seal.SEALContext(parms)

keygen = seal.KeyGenerator(context)
public_key = keygen.create_public_key()
secret_key = keygen.secret_key()
relin_keys = keygen.create_relin_keys()

encryptor = seal.Encryptor(context, public_key)
evaluator = seal.Evaluator(context)
encoder = seal.CKKSEncoder(context)
decryptor = seal.Decryptor(context, secret_key)

_ones = [1.0] * (poly_modulus_degree // 2)
