#!/usr/bin/env python3


def first(iterable):
    if iterable == set():
        return None
    return next(iter(iterable))


def is_all_cipher(nodes):
    from .cipher_node import CipherNode, FreeNode, PlainNode

    return all((type(node) is CipherNode for node in nodes))


def is_one_plain(nodes):
    from .cipher_node import CipherNode, FreeNode, PlainNode

    free_count = 0
    cipher_count = 0
    for node in nodes:
        if type(node) is PlainNode:
            free_count += 1
        if type(node) is CipherNode:
            cipher_count += 1
    return free_count == cipher_count == 1


def get_plain_node(nodes) -> "PlainNode":
    from .cipher_node import CipherNode, FreeNode, PlainNode

    for node in nodes:
        if type(node) is PlainNode:
            return node


def get_cipher_node(nodes) -> "CipherNode":
    from .cipher_node import CipherNode, FreeNode, PlainNode

    for node in nodes:
        if type(node) is CipherNode:
            return node
