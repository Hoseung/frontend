#!/usr/bin/env python3
from collections import deque
import copy


class Node:
    """Base class for inheriting nodes."""

    def __init__(self, children, parents):
        """Must provide set of children and parents."""
        self.children = children
        self.parents = parents
        self.depth = 0

    @property
    def neighbors(self):
        """
        Return all node connections.

        Includes both self.parents and self.children
        as a set union.
        """
        return self.children.union(self.parents)

    def copy(self):
        """Copy node without children/parent connections."""
        dup = copy.copy(self)
        dup.parents = set()
        dup.children = set()
        dup.depth = self.depth

        return dup

    def debug(self):
        """Print debug info."""
        print("=== Problem node ===")
        print(self)
        print("parents:", self.parents)
        print("children:", self.children)

    def traverse_children(self):
        """BFS generator of children."""
        queue = deque()
        queue.append(self)
        while queue:
            node = queue.popleft()

            # Yield all nodes but self
            if node != self:
                yield node

            for par in node.children:
                queue.append(par)

    def traverse_parents(self, duplicate=True):
        """BFS generator of parents."""
        queue = deque()
        queue.append(self)

        visited = set()
        visited.add(self)
        while queue:
            node = queue.popleft()

            # Yield all nodes but self
            if node != self:
                yield node

            for par in node.parents:
                if not duplicate:
                    if par in visited:
                        continue
                queue.append(par)
                visited.add(par)

    def traverse_neighbors(self):
        """BFS generator of parents."""
        queue = deque()
        queue.append(self)

        visited = set()
        visited.add(self)
        while queue:
            node = queue.popleft()

            # Yield all nodes but self
            if node != self:
                yield node

            for par in node.neighbors:
                if par in visited:
                    continue
                queue.append(par)
                visited.add(par)


def insert_between(child: Node, parent: Node, to_insert: Node):
    """
    Insert a new node between child and parent.

    Mutates the graph structure inplace.
    """
    assert child in parent.children

    # Unlink old
    parent.children.remove(child)
    child.parents.remove(parent)

    # Insert new
    parent.children.add(to_insert)
    to_insert.parents.add(parent)

    to_insert.children.add(child)
    child.parents.add(to_insert)


def pad_all(node: Node, padding: Node):
    """
    Insert padding & parent.copy() after node and relink all node.children.

    Mutates the graph structure inplace.
    Returns parent.copy()
    """
    padded = node.copy()

    padded.children = node.children

    for child in padded.children:
        child.parents.remove(node)
        child.parents.add(padded)

    padded.parents = set([padding])

    padding.parents.add(node)
    padding.children.add(padded)

    node.children = set([padding])

    return padded


def pad(child: Node, parent: Node, padding: Node):
    """
    Insert padding & parent.copy() between child and parent.

    Mutates the graph structure inplace.
    Returns parent.copy()
    """
    padded = parent.copy()

    padded.children = set([child])
    padded.parents = set([padding])

    parent.children.remove(child)
    parent.children.add(padding)

    padding.parents.add(parent)
    padding.children.add(padded)

    return padded


def substitute(new_node: Node, old_node: Node):
    """
    Substite old_node with new_node.

    Mutates the graph structure inplace.
    """
    parents = old_node.parents
    children = old_node.children

    for p in parents:
        p.children.remove(old_node)
        p.children.add(new_node)

    for c in children:
        c.parents.remove(old_node)
        c.parents.add(new_node)

    new_node.parents = parents
    new_node.children = children


def remove(node: Node):
    """
    Remove a node from the graph.

    Mutates the graph structure inplace.
    """
    # Disconnect from parents
    for parent in node.parents:
        parent.children.remove(node)
    node.parents = set()
