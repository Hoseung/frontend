#!/usr/bin/env python3
from .operations import BinaryOperation


def draw_dot(root, upward=True):
    """
    Return graphviz plot of the tree.

    traverse all parents and return DOT format.
    """

    from graphviz import Digraph
    from collections import deque

    dot = Digraph()

    # BFS to draw the graph
    q = deque()
    q.append(root)
    drawn_nodes = set()
    drawn_edges = set()
    while q:
        node = q.popleft()
        shape = type(node).draw_shape
        fillcolor = "white"
        if isinstance(node, BinaryOperation) and node.isexecuted:
            fillcolor = "green"

        if node not in drawn_nodes:
            dot.node(
                name=str(id(node)),
                label=node.__repr__(),
                shape=shape,
                style="filled",
                fillcolor=fillcolor,
            )
        drawn_nodes.add(node)

        if upward:
            next_nodes = node.parents
        else:
            next_nodes = node.children

        for par in next_nodes:
            q.append(par)
            edge = frozenset([par, node])
            if edge not in drawn_edges:
                dot.edge(
                    str(id(par)),
                    str(id(node)),
                )
                drawn_edges.add(edge)

    return dot
