//===- Passes.h - Toy Passes Definition -----------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//
//
// This file exposes the entry points to create compiler passes for Toy.
//
//===----------------------------------------------------------------------===//

#ifndef TOY_PASSES_H
#define TOY_PASSES_H

#include <memory>

//===- Passes.h - Linalg pass entry points ----------------------*- C++ -*-===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//
//
// This header file defines prototypes that expose pass constructors.
//
//===----------------------------------------------------------------------===//


#include "mlir/Pass/Pass.h"

namespace mlir {
  namespace func {
    class FuncOp;
  } // namespace func

#define GEN_PASS_DECL
#include "hecomp/Conversion/Passes.h.inc"

  std::unique_ptr<OperationPass<func::FuncOp>> createRelinInsertionPass();
  std::unique_ptr<OperationPass<func::FuncOp>> createHIRToCKKSConversionPass();
  std::unique_ptr<OperationPass<func::FuncOp>> createCKKSToLibConversionPass();

  /// Generate the code for registering passes.
#define GEN_PASS_REGISTRATION
#include "hecomp/Conversion/Passes.h.inc"

}

#endif
