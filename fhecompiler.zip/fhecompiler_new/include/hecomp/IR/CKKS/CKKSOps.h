#ifndef CKKSDIALECT_H
#define CKKSDIALECT_H

#include "mlir/IR/Builders.h"
#include "mlir/IR/BuiltinOps.h"
#include "mlir/IR/BuiltinTypes.h"
#include "mlir/IR/Dialect.h"
#include "mlir/IR/OpDefinition.h"
#include "mlir/IR/OpImplementation.h"
#include "mlir/IR/PatternMatch.h"
#include "mlir/Interfaces/CallInterfaces.h"
#include "mlir/Interfaces/CastInterfaces.h"
#include "mlir/Interfaces/ControlFlowInterfaces.h"
#include "mlir/Interfaces/CopyOpInterface.h"
#include "mlir/Interfaces/InferTypeOpInterface.h"
#include "mlir/Interfaces/SideEffectInterfaces.h"
#include "hecomp/IR/HIR/HIROps.h"

// Include the C++ class declaration for this Dialect (no define necessary for this one)
#include "hecomp/IR/CKKS/CKKSDialect.h.inc"


// Include the C++ class (and associated functions) declarations for this Dialect's operations
#define GET_OP_CLASSES
#include "hecomp/IR/CKKS/CKKSOps.h.inc"
#endif // CKKSDIALECT_H

namespace mlir{
    namespace ckks {
        using CipherType=mlir::hir::CipherType;
        using VectorType=mlir::hir::VectorType;
    }
}