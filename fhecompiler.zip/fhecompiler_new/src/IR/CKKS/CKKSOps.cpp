#include "hecomp/IR/CKKS/CKKSOps.h"
#include "llvm/ADT/SmallString.h"
#include "llvm/ADT/TypeSwitch.h"
#include "mlir/Dialect/EmitC/IR/EmitC.h"
#include "mlir/IR/DialectImplementation.h"
#include "mlir/IR/PatternMatch.h"
#include "mlir/IR/TypeSupport.h"
#include "mlir/IR/Types.h"
#include "mlir/Support/LLVM.h"
#include "hecomp/IR/HIR/HIROps.h"

//===----------------------------------------------------------------------===//
// TableGen'd Type definitions
//===----------------------------------------------------------------------===//

//===----------------------------------------------------------------------===//
// TableGen'd Operation definitions
//===----------------------------------------------------------------------===//

#define GET_OP_CLASSES
#include "hecomp/IR/CKKS/CKKSOps.cpp.inc"


mlir::LogicalResult mlir::ckks::MultiplyOp::inferReturnTypes(
    ::mlir::MLIRContext *context, ::llvm::Optional<::mlir::Location> location, ::mlir::ValueRange operands,
    ::mlir::DictionaryAttr attributes, ::mlir::RegionRange regions,
    ::llvm::SmallVectorImpl<::mlir::Type> &inferredReturnTypes)
{
  // Operand adaptors (https://mlir.llvm.org/docs/OpDefinitions/#operand-adaptors) provide a convenient way to access
  // operands when given as a "generic" triple of ValueRange, DictionaryAttr, RegionRange  instead of nicely
  // "packaged" inside the operation class.
  auto op = MultiplyOpAdaptor(operands, attributes, regions);
  int size = -173;
  for (auto operand : {op.getX(), op.getY()})
  {
    if (auto ctxt = operand.getType().dyn_cast_or_null<CipherType>()) {
      size = ctxt.getSize();
    }
    if (auto ptxt = operand.getType().dyn_cast_or_null<VectorType>()) {
      size = ptxt.getSize();
    }

    // TODO: check things properly! (including encryption parameters)
  }

  // it's always a ciphertext (according to the CKKS paper)
  inferredReturnTypes.push_back(CipherType::get(context, size, -1, -1));
  return ::mlir::success();
}

mlir::LogicalResult mlir::ckks::AddOp::inferReturnTypes(
    ::mlir::MLIRContext *context, ::llvm::Optional<::mlir::Location> location, ::mlir::ValueRange operands,
    ::mlir::DictionaryAttr attributes, ::mlir::RegionRange regions,
    ::llvm::SmallVectorImpl<::mlir::Type> &inferredReturnTypes)
{
  // Operand adaptors (https://mlir.llvm.org/docs/OpDefinitions/#operand-adaptors) provide a convenient way to access
  // operands when given as a "generic" triple of ValueRange, DictionaryAttr, RegionRange  instead of nicely
  // "packaged" inside the operation class.
  auto op = AddOpAdaptor(operands, attributes, regions);
  int size = -173;
  for (auto operand : {op.getX(), op.getY()})
  {
    if (auto ctxt = operand.getType().dyn_cast_or_null<CipherType>()) {
      size = ctxt.getSize();
    }
    if (auto ptxt = operand.getType().dyn_cast_or_null<VectorType>()) {
      size = ptxt.getSize();
    }

    // TODO: check things properly! (including encryption parameters)
  }

  // it's always a ciphertext (according to the CKKS paper)
  inferredReturnTypes.push_back(CipherType::get(context, size, -1, -1));
  return ::mlir::success();
}


mlir::LogicalResult mlir::ckks::SubOp::inferReturnTypes(
    ::mlir::MLIRContext *context, ::llvm::Optional<::mlir::Location> location, ::mlir::ValueRange operands,
    ::mlir::DictionaryAttr attributes, ::mlir::RegionRange regions,
    ::llvm::SmallVectorImpl<::mlir::Type> &inferredReturnTypes)
{
  // Operand adaptors (https://mlir.llvm.org/docs/OpDefinitions/#operand-adaptors) provide a convenient way to access
  // operands when given as a "generic" triple of ValueRange, DictionaryAttr, RegionRange  instead of nicely
  // "packaged" inside the operation class.
  auto op = SubOpAdaptor(operands, attributes, regions);
  int size = -173;
  for (auto operand : {op.getX(), op.getY()})
  {
    if (auto ctxt = operand.getType().dyn_cast_or_null<CipherType>()) {
      size = ctxt.getSize();
    }
    if (auto ptxt = operand.getType().dyn_cast_or_null<VectorType>()) {
      size = ptxt.getSize();
    }

    // TODO: check things properly! (including encryption parameters)
  }

  // it's always a ciphertext (according to the CKKS paper)
  inferredReturnTypes.push_back(CipherType::get(context, size, -1, -1));
  return ::mlir::success();
}

mlir::LogicalResult mlir::ckks::ConstOp::inferReturnTypes(
    ::mlir::MLIRContext *context, ::llvm::Optional<::mlir::Location> location, ::mlir::ValueRange operands,
    ::mlir::DictionaryAttr attributes, ::mlir::RegionRange regions,
    ::llvm::SmallVectorImpl<::mlir::Type> &inferredReturnTypes)
{
  // Operand adaptors (https://mlir.llvm.org/docs/OpDefinitions/#operand-adaptors) provide a convenient way to access
  // operands when given as a "generic" triple of ValueRange, DictionaryAttr, RegionRange  instead of nicely
  // "packaged" inside the operation class.
  auto op = ConstOpAdaptor(operands, attributes, regions);
  inferredReturnTypes.push_back(CipherType::get(context, -1, -1, -1));
  return ::mlir::success();
  /* if (auto da = op.getValue().dyn_cast_or_null<DenseElementsAttr>()) */
  /* { */
  /*   // TODO: set size and encryption parameters correctly */
  /*   inferredReturnTypes.push_back(CipherType::get(context, -1, -1, -1)); */
  /*   return ::mlir::success(); */
  /* } */
  /* else */
  /* { */
  /*   inferredReturnTypes.push_back(CipherType::get(context, -1, -1, -1)); */
  /*   return ::mlir::success(); */
  /*   /1* return ::mlir::failure(); *1/ */
  /* } */
}

void ::mlir::ckks::ConstOp::getAsmResultNames(function_ref<void(Value, StringRef)> setNameFn)
{

  // TODO: Somehow support array stuff better?
  setNameFn(getResult(), "vcst");
}

/// simplifies away negation(negation(x)) to x if the types work

//===----------------------------------------------------------------------===//
// CKKS dialect definitions
//===----------------------------------------------------------------------===//
#include "hecomp/IR/CKKS/CKKSDialect.cpp.inc"
void mlir::ckks::CKKSDialect::initialize()
{

  // Registers all the Operations into the CKKSDialect class
  addOperations<
#define GET_OP_LIST
#include "hecomp/IR/CKKS/CKKSOps.cpp.inc"
    >();
}
