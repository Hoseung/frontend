#include "hecomp/Conversion/Passes.h"
#include "hecomp/IR/CKKS/CKKSOps.h"
#include "mlir/Dialect/Func/IR/FuncOps.h"
#include "mlir/IR/BuiltinDialect.h"
#include "mlir/IR/Operation.h"
#include "mlir/Pass/Pass.h"

namespace mlir {
#define GEN_PASS_DEF_RELININSERTION
#include "hecomp/Conversion/Passes.h.inc"
}

using namespace mlir;
using namespace mlir::ckks;

namespace {
  struct RelinInsertionPass
    : public impl::RelinInsertionBase<RelinInsertionPass> {
      void runOnOperation() override {
        /* llvm::errs() << "Relin Insertion Pass\n"; */
        mlir::func::FuncOp func = getOperation();
        auto&& blocks = func.getBlocks();
        for (auto&& block : func.getBlocks()){
          for (MultiplyOp op : block.getOps<mlir::ckks::MultiplyOp>()) {
            OpBuilder builder (op);
            builder.setInsertionPointAfter(op);
            // Create does not enforce the users of multiplication to use "relinearized result
            IRRewriter rewriter (builder);

            auto relin = builder.create<mlir::ckks::RelinearizeOp>(builder.getUnknownLoc(), op);
            // change the use of "op" to "relin"
            /* op.replaceAllUsesWith(relin.getOperation()); */
            rewriter.replaceAllUsesExcept(op, relin, relin);

          }
        }
      }
    };
}; // namespace


std::unique_ptr<OperationPass<func::FuncOp>> mlir::createRelinInsertionPass() {
  return std::make_unique<RelinInsertionPass>();
}
