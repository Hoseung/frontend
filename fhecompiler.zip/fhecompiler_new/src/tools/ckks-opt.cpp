#include "mlir/Dialect/Func/IR/FuncOps.h"
#include "mlir/Pass/PassManager.h"
#include "mlir/Transforms/Passes.h"
#include "hecomp/IR/HIR/HIROps.h"
#include "hecomp/Conversion/Passes.h"
#include <nlohmann/json.hpp>
#include <iostream>
#include <fstream>
#include <vector>

// for convenience
using json = nlohmann::json;

std::vector<std::vector<int>> makeGraph(json& graph);
void processGraph(json& graph, std::vector<std::vector<int>> adj_list);

int main(int argc, char ** argv) {
  std::cout << argv[0] << std::endl;
  std::cout << argv[1] << std::endl;

  std::string s ( argv[1]);
  std::cout<< s << std::endl;

  std::ifstream ifs(s);
  std::string merged;
  std::string line;
  while (std::getline(ifs, line))
  {
    merged += line;
  }
  json j = json::parse(merged);
  /* if (j.is_discarded()) */
  /* { */
  /*   std::cout << "parse error" << std::endl; */
  /* } else { */
  /*   std::cout << "parsed" << std::endl; */
  /* } */
  processGraph(j,makeGraph(j));
}

std::vector<std::vector<int>> makeGraph(json& graph){
  std::vector<std::vector<int>> adj_list;
  //std::cout << graph["nodes"].size()<<std::endl; //node count
  adj_list.resize(graph["nodes"].size()+1);
  for (auto&& entry : graph["links"]){
    adj_list[entry["source"]].push_back(entry["target"]);
  }
  /* for (int i = 1 ; i < adj_list.size(); i++){ std::cout << i << ":" << " "; */
  /*   for (int j = 0 ; j < adj_list[i].size() ; j++){ */
  /*     std:: cout << adj_list[i][j] << " "; */
  /*   } */
  /*   std::cout << std::endl; */
  /* } */
  return adj_list;
}

void processGraph(json& graph, std::vector<std::vector<int>> adj_list){
  mlir::MLIRContext ctxt;
  ctxt.loadAllAvailableDialects();
  ctxt.getOrLoadDialect<mlir::func::FuncDialect>();
  ctxt.getOrLoadDialect<mlir::hir::HIRDialect>();
  mlir::OpBuilder builder(&ctxt);//operation build

  auto module = builder.create<mlir::ModuleOp>(builder.getUnknownLoc());
  builder.setInsertionPointToStart(module.getBody(0));


  llvm::SmallVector<mlir::Type, 4> retTypes(1,
      builder.getType<mlir::hir::CipherType>(2, -1, -1));
  auto funcType = builder.getFunctionType({}, retTypes);

  auto func = builder.create<mlir::func::FuncOp>(builder.getUnknownLoc(), "test", funcType);

  auto block =func.addEntryBlock();
  builder.setInsertionPointToStart(block);

  std::vector<mlir::Value> values;
  values.resize(graph["nodes"].size()+1); // initialize the elements before access
  
  for (int n = graph["nodes"].size()-1; n >= 0; n--){ // back node to front node
    int i = int(graph["topsort"][n]) - 1;
    std::string typestr = graph["nodes"][i]["type"];
    int idx = graph["nodes"][i]["id"];
    /* llvm::errs() << typestr<< "\n"; */
    /* llvm::errs() << i << "\n"; */
    if (typestr == "<class 'compyler.cipher_node.CipherNode'>"){
      auto&& typeinfo = graph["nodes"][i]["params"];
      int level = typeinfo["level"];
      int scale = typeinfo["scale"];
      std::string label = graph["nodes"][i]["label"];
      auto && opType = builder.getType<mlir::hir::CipherType>(2, scale, level);
      auto && nameAttr = builder.getStringAttr(label.c_str());
      auto load = builder.create<mlir::hir::CiphertextLoadOp>(builder.getUnknownLoc(), opType, nameAttr);
      values[idx] = load; 
      // load is a variable of "CiphertextLoadOp" type but can be implicitly casted to mlir::Value

      /* auto && operand_list= adj_list[graph["nodes"][i]["id"]]; */ 
      /* std::cout <<  graph["nodes"][i]["id"]<< std::endl; */
      /* if (operand_list.size() == 1) { */
      /*   operand_list */
      /* } else if (operand_list.size() == 2){ */
      /*   operand_list */
      /* } */
    } else if (typestr == "<class 'compyler.cipher_node.FreeNode'>"){
      /* llvm::errs() << __LINE__ << "\n"; */
      values[idx] = values[adj_list[idx][0]];
    } else if (typestr == "<class 'compyler.cipher_node.PlainNode'>"){
      auto constant = builder.create<mlir::hir::ConstOp>(builder.getUnknownLoc(), builder.getDenseF64ArrayAttr({graph["nodes"][i]["value"]}));
      values[idx] = constant;

    } else if (typestr == "<class 'compyler.operations.Negation'>"){
      auto negate = builder.create<mlir::hir::NegateOp>(builder.getUnknownLoc(), values[adj_list[idx][0]]);
      values[idx] = negate;

    } else if (typestr == "<class 'compyler.operations.Addition'>"){
      auto add = builder.create<mlir::hir::AddOp>(builder.getUnknownLoc(), values[adj_list[idx][0]], values[adj_list[idx][1]]);
      values[idx] = add;
    } else if (typestr == "<class 'compyler.operations.Multiplication'>"){
      auto mul = builder.create<mlir::hir::MultiplyOp>(builder.getUnknownLoc(), values[adj_list[idx][0]], values[adj_list[idx][1]]);
      values[idx] = mul;
    } else if (typestr == "<class 'compyler.operations.Mean'>"){
      auto mean = builder.create<mlir::hir::MeanOp>(builder.getUnknownLoc(), values[adj_list[idx][0]]);
      values[idx] = mean;
    } else if (typestr == "<class 'compyler.operations.Std'>"){
      auto std = builder.create<mlir::hir::StdOp>(builder.getUnknownLoc(), values[adj_list[idx][0]]);
      values[idx] = std;
    } else if (typestr == "<class 'compyler.operations.Var'>"){
      auto var = builder.create<mlir::hir::VarOp>(builder.getUnknownLoc(), values[adj_list[idx][0]]);
      values[idx] = var;
    }

    if (graph["nodes"][i]["root"]){
      builder.create<mlir::func::ReturnOp> (builder.getUnknownLoc(), llvm::SmallVector<mlir::Value, 4>{values[idx]});
      llvm::SmallVector<mlir::Type, 4> retTypes(1,
          values[idx].getType());
      auto funcType = builder.getFunctionType({}, retTypes);
      func.setFunctionType(funcType);
    }
  }

  mlir::PassManager pm(&ctxt);
  applyPassManagerCLOptions(pm);
  mlir::OpPassManager &optPM = pm.nest<mlir::func::FuncOp>();
  optPM.addPass(mlir::createCanonicalizerPass());
  optPM.addPass(mlir::createCSEPass());
  optPM.addPass(mlir::createHIRToCKKSConversionPass());
  // optPM.addPass(mlir::createRelinInsertionPass());
  optPM.addPass(mlir::createCKKSToLibConversionPass());
  if (mlir::failed(pm.run(module)))
    return ;
  module.dump();
}
