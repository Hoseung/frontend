#include "hecomp/IR/CKKS/CKKSOps.h"
#include "hecomp/IR/HIR/HIROps.h"
#include "hecomp/Conversion/Passes.h"

#include "mlir/Conversion/ArithCommon/AttrToLLVMConverter.h"
#include "mlir/Transforms/GreedyPatternRewriteDriver.h"
#include "mlir/IR/TypeUtilities.h"
#include "mlir/IR/Value.h"
#include "mlir/Pass/Pass.h"
#include "mlir/Transforms/DialectConversion.h"
#include <type_traits>
#include <mlir/Dialect/Func/IR/FuncOps.h>
#include "hecomp/Conversion/Passes.h"
#include <filesystem>
#include <fstream>
#include <cstdlib>

#include <filesystem>
namespace fs = std::filesystem;


namespace mlir {
#define GEN_PASS_DEF_CKKSTOLIBCONVERSION
#include "hecomp/Conversion/Passes.h.inc"
namespace ckks{
  void populateCKKSToLibConversionPatterns(
    mlir::MLIRContext *ctxt, 
    mlir::RewritePatternSet &patterns);
}
}

using namespace mlir;


namespace {
/// Pass to bufferize Arith ops.
struct CKKSToLibConversionPass : public mlir::impl::CKKSToLibConversionBase<CKKSToLibConversionPass> {
  CKKSToLibConversionPass() {}

  void runOnOperation() override {
    markAllAnalysesPreserved();
    auto &&func = getOperation();

    int64_t cipher_registers = 0;
    int64_t plain_registers = 0;
    llvm::DenseMap<mlir::Value, int64_t> cipher_register_file;
    llvm::DenseMap<mlir::Value, int64_t> plain_register_file;

    int count = 0;
    auto funcName = func.getName();
    std::string path(std::getenv("HOME"));
    path += "/.local/bin/fhe_jit";
    fs::create_directories(path);
    llvm::errs() << path <<"\n";
    llvm::DenseMap <mlir::Value, std::string> valueMap;
    std::error_code EC;
    llvm::raw_fd_ostream of(path+"/out.py", EC);
    of << "import numpy as np\n";
    of << "import compyler.backend as backend\n";

    llvm::DenseMap<llvm::StringRef, mlir::Value> inputs;
    func.walk ([&] (mlir::Operation *op){
      if (auto cipher = dyn_cast<ckks::CiphertextLoadOp>(op)){
        inputs[cipher.getInput().dyn_cast<StringAttr>()] = cipher;
      }
    });
    of << "def " << funcName << "(" ;

    bool first = true;
    for (auto kv : inputs) {
      if (first) {
      first = false;
      } else {
      of << ", " ;
      }
      of << kv.first;
      valueMap[kv.second] = kv.first;
      count ++ ;
    }
    of <<  ") : \n";  
    // valueMap[inputs[func.getNumArguments() -1 ]] = count;
    // count ++ ; 

    func.walk ([&] (mlir::Operation * op) {

    auto genFunc = [&] () {
      valueMap[op->getResult(0)] = "v" + std::to_string(count);
      of << "  ";
      of << "v" << count << "= ";
      count ++ ; 
    };
    if (auto mul = dyn_cast<ckks::MultiplyOp>(op)) {
      genFunc();
    of << "backend.mult(";
    of << valueMap[mul.getX()] << ", ";
    of << valueMap[mul.getY()] << ")";
    }  else if (auto cipher = dyn_cast<ckks::CiphertextLoadOp>(op)){
      valueMap[cipher.getResult()] = cipher.getInput().dyn_cast<StringAttr>().str();
      return;
    }else if (auto cons = dyn_cast<ckks::ConstOp>(op)){
    // of << "engine.encode(";
    // of << valueMap[cons.getValue()] << ", level=0)";
          genFunc();
      of << "np.array([";
      for (int a : cons.getValue()) {
        of << a << ",";
      }
      of << "] * 32768)";  // constant list //32768전까지 repeat하게 수정
    } else if (auto neg = dyn_cast<ckks::NegateOp>(op)) {
              genFunc();
      of << "backend.negate(";
      of << valueMap[neg.getInput()] << ")";
    } else if (auto add = dyn_cast<ckks::AddOp>(op)) {
              genFunc();
      of << "backend.add(";
      of << valueMap[add.getX()] << ", ";
      of << valueMap[add.getY()] << ")";
    } else if (auto sub = dyn_cast<ckks::SubOp>(op)) {
              genFunc();
      of << "backend.sub(";
      of << valueMap[add.getX()] << ", ";
      of << valueMap[add.getY()] << ")";
    } else if (auto rot = dyn_cast<ckks::RotateOp>(op)){
              genFunc();
      of << "backend.rotate_galois(";
      of << valueMap[rot.getX()]  << rot.getI() << ")";
    } else if (auto relin = dyn_cast<ckks::RelinearizeOp>(op)){
              genFunc();
      of << "backend.relinearize(";
      of << valueMap[relin.getX()] << ")";
    } else if (auto ret = dyn_cast<mlir::func::ReturnOp>(op)){
      of << "  return ";
      bool first = true;
      for (auto&& arg : ret.getOperands()) {
        if (first) {
          first = false;
        } else {
          of << ", ";
        }
        of << valueMap[arg];
      }
    } else if (auto mean = dyn_cast<hir::MeanOp>(op)){
      genFunc();
      of << "backend.mean(";
      of << valueMap[mean.getX()] << ")";
    } else if (auto std = dyn_cast<hir::StdOp>(op)){
      genFunc();
      of << "backend.std(";
      of << valueMap[std.getX()] << ")";
    } else if (auto var = dyn_cast<hir::VarOp>(op)){
      genFunc();
      of << "backend.var(";
      of << valueMap[var.getX()] << ")";
    }
    of << "\n";
    } 
    );
    of.close();
  }

  void getDependentDialects(DialectRegistry &registry) const override {
    registry.insert<mlir::ckks::CKKSDialect>();
    registry.insert<mlir::hir::HIRDialect>();
  }
};
} // namespace

std::unique_ptr<::mlir::OperationPass<::mlir::func::FuncOp>>
mlir::createCKKSToLibConversionPass() {
  return std::make_unique<CKKSToLibConversionPass>();
}