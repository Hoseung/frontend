
#include "hecomp/IR/CKKS/CKKSOps.h"
#include "hecomp/IR/HIR/HIROps.h"

#include "mlir/Conversion/ArithCommon/AttrToLLVMConverter.h"
#include "mlir/IR/TypeUtilities.h"
#include "mlir/IR/Value.h"
#include "mlir/Pass/Pass.h"
#include "mlir/Transforms/DialectConversion.h"
#include <type_traits>
#include <mlir/Dialect/Func/IR/FuncOps.h>
#include "hecomp/Conversion/Passes.h"


namespace mlir {
#define GEN_PASS_DEF_HIRTOCKKSCONVERSION
#include "hecomp/Conversion/Passes.h.inc"
namespace hir{
  void populateHIRToCKKSConversionPatterns(
    mlir::MLIRContext *ctxt, 
    mlir::RewritePatternSet &patterns);
}
}

using namespace mlir;

namespace {

//===----------------------------------------------------------------------===//
// Straightforward Op Lowerings
//===----------------------------------------------------------------------===//

//===----------------------------------------------------------------------===//
// Op Lowering Patterns
//===----------------------------------------------------------------------===//

struct CiphertextLoadOpLowering
    : public OpConversionPattern<mlir::hir::CiphertextLoadOp> {
  using OpConversionPattern<mlir::hir::CiphertextLoadOp>::ConversionPattern;
  CiphertextLoadOpLowering(MLIRContext *ctxt
                    )
      : OpConversionPattern<mlir::hir::CiphertextLoadOp>(ctxt)
       {}

  LogicalResult
  matchAndRewrite(mlir::hir::CiphertextLoadOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override;
};

struct ConstantOpLowering
    : public OpConversionPattern<mlir::hir::ConstOp> {
  using OpConversionPattern<mlir::hir::ConstOp>::ConversionPattern;
  ConstantOpLowering(MLIRContext *ctxt
                    )
      : OpConversionPattern<mlir::hir::ConstOp>(ctxt)
       {}

  LogicalResult
  matchAndRewrite(mlir::hir::ConstOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override;
};

struct NegateOpLowering : public OpConversionPattern<mlir::hir::NegateOp> {
  using OpConversionPattern<mlir::hir::NegateOp>::ConversionPattern;
  NegateOpLowering(MLIRContext *ctxt)
      : OpConversionPattern<mlir::hir::NegateOp>(ctxt) {}

  LogicalResult
  matchAndRewrite(mlir::hir::NegateOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override;
};

struct AddOpLowering : public OpConversionPattern<mlir::hir::AddOp> {
  using OpConversionPattern<mlir::hir::AddOp>::ConversionPattern;
  AddOpLowering(MLIRContext *ctxt)
      : OpConversionPattern<mlir::hir::AddOp>(ctxt) {}

  LogicalResult
  matchAndRewrite(mlir::hir::AddOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override;
};

struct SubOpLowering : public OpConversionPattern<mlir::hir::SubOp> {
  using OpConversionPattern<mlir::hir::SubOp>::ConversionPattern;
  SubOpLowering(MLIRContext *ctxt)
      : OpConversionPattern<mlir::hir::SubOp>(ctxt) {}

  LogicalResult
  matchAndRewrite(mlir::hir::SubOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override;
};

struct MulOpLowering : public OpConversionPattern<mlir::hir::MultiplyOp> {
  using OpConversionPattern<mlir::hir::MultiplyOp>::ConversionPattern;
  MulOpLowering(MLIRContext *ctxt)
      : OpConversionPattern<mlir::hir::MultiplyOp>(ctxt) {}

  LogicalResult
  matchAndRewrite(mlir::hir::MultiplyOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override;
};



struct RotateOpLowering : public OpConversionPattern<mlir::hir::RotateOp> {
  using OpConversionPattern<mlir::hir::RotateOp>::ConversionPattern;
  RotateOpLowering(MLIRContext *ctxt)
      : OpConversionPattern<mlir::hir::RotateOp>(ctxt) {}

  LogicalResult
  matchAndRewrite(mlir::hir::RotateOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override;
};

struct ReturnOpLowering : public OpConversionPattern<mlir::func::ReturnOp> {
  using OpConversionPattern<mlir::func::ReturnOp>::ConversionPattern;
  ReturnOpLowering(MLIRContext *ctxt)
      : OpConversionPattern<mlir::func::ReturnOp>(ctxt) {}

  LogicalResult
  matchAndRewrite(mlir::func::ReturnOp op, OpAdaptor adaptor,
                  ConversionPatternRewriter &rewriter) const override;
};

} // namespace

//===----------------------------------------------------------------------===//
// CiphertextLoadOpLowering
//===----------------------------------------------------------------------===//

LogicalResult
CiphertextLoadOpLowering::matchAndRewrite(mlir::hir::CiphertextLoadOp op, OpAdaptor adaptor,
                                  ConversionPatternRewriter &rewriter) const {
  rewriter.replaceOpWithNewOp<ckks::CiphertextLoadOp>(
    op, op.getResult().getType(), adaptor.getInput());

  return success();
}

//===----------------------------------------------------------------------===//
// ConstantOpLowering
//===----------------------------------------------------------------------===//

LogicalResult
ConstantOpLowering::matchAndRewrite(mlir::hir::ConstOp op,
                                    OpAdaptor adaptor,
                                    ConversionPatternRewriter &rewriter) const {
  
  rewriter.replaceOpWithNewOp<ckks::ConstOp>(
      op, adaptor.getValue());

  return success();
}

//===----------------------------------------------------------------------===//
// NegateOpLowering
//===----------------------------------------------------------------------===//

LogicalResult
NegateOpLowering::matchAndRewrite(mlir::hir::NegateOp op, OpAdaptor adaptor,
                                  ConversionPatternRewriter &rewriter) const {

  rewriter.replaceOpWithNewOp<ckks::NegateOp>(
    op, adaptor.getInput());

  return success();
}

//===----------------------------------------------------------------------===//
// AddOpLowering
//===----------------------------------------------------------------------===//

LogicalResult
AddOpLowering::matchAndRewrite(mlir::hir::AddOp op, OpAdaptor adaptor,
                               ConversionPatternRewriter &rewriter) const {
  rewriter.replaceOpWithNewOp<ckks::AddOp>(
    op, adaptor.getX(), adaptor.getY());

  return success();
}

//===----------------------------------------------------------------------===//
// SubOpLowering
//===----------------------------------------------------------------------===//

LogicalResult
SubOpLowering::matchAndRewrite(mlir::hir::SubOp op, OpAdaptor adaptor,
                               ConversionPatternRewriter &rewriter) const {
  rewriter.replaceOpWithNewOp<ckks::SubOp>(
    op, adaptor.getX(), adaptor.getY());

  return success();
}

//===----------------------------------------------------------------------===//
// MulOpLowering
//===----------------------------------------------------------------------===//

LogicalResult
MulOpLowering::matchAndRewrite(mlir::hir::MultiplyOp op, OpAdaptor adaptor,
                               ConversionPatternRewriter &rewriter) const {
  rewriter.replaceOpWithNewOp<ckks::MultiplyOp>(
    op, adaptor.getX(), adaptor.getY());
  
  return success();
}

//===----------------------------------------------------------------------===//
// RotateOpLowering
//===----------------------------------------------------------------------===//

LogicalResult
RotateOpLowering::matchAndRewrite(mlir::hir::RotateOp op, OpAdaptor adaptor,
                                  ConversionPatternRewriter &rewriter) const {
  rewriter.replaceOpWithNewOp<ckks::RotateOp>(
    op, adaptor.getX(), adaptor.getI());

  return success();
}

//===----------------------------------------------------------------------===//
// ReturnOpLowering
//===----------------------------------------------------------------------===//

LogicalResult
ReturnOpLowering::matchAndRewrite(func::ReturnOp op, OpAdaptor adaptor,
                                  ConversionPatternRewriter &rewriter) const {

  rewriter.replaceOpWithNewOp<func::ReturnOp>(op, adaptor.getOperands());
  return success();
}

//===----------------------------------------------------------------------===//
// Pass Definition
//===----------------------------------------------------------------------===//

namespace {
struct HIRToCKKSConversion
    : public mlir::impl::HIRToCKKSConversionBase<HIRToCKKSConversion> {
  using Base::Base;

  void runOnOperation() override {
    ConversionTarget target(getContext());

    auto func = getOperation();

    mlir::RewritePatternSet patterns(&getContext());

    target.addLegalDialect<mlir::ckks::CKKSDialect>();
        target.addDynamicallyLegalOp<func::ReturnOp>([&](func::ReturnOp rop) {
      return llvm::all_of(rop.getOperands(), [&](auto &&v) {
        if (v.getDefiningOp())
        // add intrinsic function 
          return isa<mlir::ckks::CKKSDialect>(v.getDefiningOp()->getDialect()) ||
                  isa<mlir::hir::MeanOp> (v.getDefiningOp()) || 
                  isa<mlir::hir::StdOp> (v.getDefiningOp()) || 
                  isa<mlir::hir::VarOp> (v.getDefiningOp()) ;
        else 
          return true;
      });
    });
    target.addIllegalOp<
    #define GET_OP_LIST //get HIR Ops
    #include "hecomp/IR/HIR/HIROps.cpp.inc"
    >();

    mlir::hir::populateHIRToCKKSConversionPatterns(
        &getContext(), patterns);

    if (failed(applyPartialConversion(getOperation(), target,
                                      std::move(patterns))))
      signalPassFailure();
  }
};
} // namespace

//===----------------------------------------------------------------------===//
// Pattern Population
//===----------------------------------------------------------------------===//
//
void mlir::hir::populateHIRToCKKSConversionPatterns(
    mlir::MLIRContext *ctxt, 
    mlir::RewritePatternSet &patterns) {
  // clang-format off
  patterns.add<
    MulOpLowering,
    AddOpLowering,
    SubOpLowering,
    NegateOpLowering,
    RotateOpLowering,
    //RescaleOpLowering, no rescale in HIR
    //ModswitchOpLowering,
    ConstantOpLowering,
    CiphertextLoadOpLowering,
    ReturnOpLowering
  >(ctxt);

  // clang-format on
}

std::unique_ptr<::mlir::OperationPass<::mlir::func::FuncOp>>
mlir::createHIRToCKKSConversionPass() {
  return std::make_unique<HIRToCKKSConversion>();
}